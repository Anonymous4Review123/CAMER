# CAMER: Anonymous AAAI Code and Data Package

This anonymous package implements **Category-Aware Multimodal Explainable Recommendation (CAMER)**. It contains the model, fixed-split data loaders, Amazon Reviews 2023 preprocessing, a TripAdvisor format converter, rating and explanation evaluation, ablation flags, and validation-loss early stopping.

No raw dataset, copyrighted product/hotel image collection, pretrained OpenLLaMA weights, or CLIP weights are redistributed. Paths in all commands are user supplied and no author, institution, server account, or private repository information is included.

## 1. Directory structure

```text
CAMER_Code_and_Data_Anonymous/
├── README.md
├── requirements.txt
├── pyproject.toml
├── LICENSE
├── THIRD_PARTY_NOTICES.md
├── configs/paper_hyperparameters.json
├── camer/
│   ├── dataset/
│   ├── eval/
│   ├── model/
│   ├── tools/
│   └── train/
├── scripts/
│   ├── run_amazon2023.sh
│   ├── prepare_tripadvisor.sh
│   └── run_tripadvisor.sh
└── sample_data/
```

## 2. Environment

The code was designed for Linux, Python 3.10+, PyTorch 2.1+, CUDA-capable GPUs, OpenLLaMA-7B-v2, and CLIP ViT-B/32. A single run requires enough memory to fine-tune OpenLLaMA-7B with LoRA. Install dependencies from the package root:

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install -e . --no-build-isolation
```

The training code deliberately sets `local_files_only=True`; therefore `MODEL_NAME` and `CLIP_PATH` must point to already downloaded local model directories.

## 3. Paper-to-code alignment

| Paper component | Implementation |
|---|---|
| Eq. (1), category-guided multimodal feature alignment | `camer.model.model.CategoryGuidedMultimodalAlignment` |
| Eq. (2)-(3), category-aware interest drift | `CategoryAwareUserPreference` temporal aggregation and decay |
| Eq. (4)-(5), category-aware modality preference | `user_modality_weights` and category-specific user state |
| Eq. (6), rating prediction | global mean + user/item bias + MLP |
| Eq. (7), multimodal item fusion | `LayerwiseModalityFusion` |
| Eq. (8), continuous prefix | `[z_u^c, z_i, e_i^c]`, projected to 16 prefix tokens |
| Eq. (9) | rating MSE |
| Eq. (10) | autoregressive negative log-likelihood |
| Eq. (11) | category contrastive loss with category-aware sampling |
| Eq. (12) | `Lpre + 1.0*Lgen + 0.1*Lcl + 1e-3*||Theta||²` |

The formal defaults are also recorded in `configs/paper_hyperparameters.json`. The code uses per-device batch size 2 and gradient accumulation 16, giving an effective batch size of 32 on one GPU.

## 4. Expected normalized data format

Training reads gzip-compressed JSONL files. Each row has the following schema:

```json
{
  "user_id": "user identifier",
  "item": "item identifier",
  "rating": 5.0,
  "timestamp": 1700000000,
  "review_text": "full review text",
  "explanation_text": "target explanation",
  "review_features": ["feature one", "feature two"],
  "item_name": "public item title",
  "description": "public item description",
  "category": "item category",
  "image_path": "/local/path/to/item_image.jpg"
}
```

Only static item metadata enters the target representation. The current target review, explanation, extracted target features, and rating are not used as prompt/prefix inputs. User histories are restricted to earlier interactions and training-visible records.

## 5. Amazon MoviesAndTV and ClothingShoesAndJewelry

Download the Amazon Reviews 2023 review and metadata files under their applicable terms. Use local image directories and relative or user-supplied paths.

### 5.1 Prepare fixed 8:1:1 splits

```bash
python -u -m camer.tools.prepare_amazon \
  --review_file /path/to/reviews.jsonl.gz \
  --meta_file /path/to/meta.jsonl.gz \
  --image_dir /path/to/item_images \
  --output_dir /path/to/processed/movies_tv \
  --domain movies_tv \
  --k_core 5 \
  --min_review_words 5 --max_review_words 100 \
  --valid_ratio 0.1 --test_ratio 0.1 \
  --split_strategy random_global --seed 42 \
  --no-semantic_backfill --require_image
```

For Clothing, replace `--domain movies_tv` with `--domain clothing`. The script writes:

```text
train.jsonl.gz  valid.jsonl.gz  test.jsonl.gz
all_cleaned.jsonl.gz  mappings.json  statistics.json
```

The preprocessing is SQLite-backed and resumable. To download image URLs exposed by Amazon metadata, first export retained item IDs with `camer.tools.finalize_amazon_images --export_only`, run `camer.tools.download_amazon_images`, and then run `camer.tools.finalize_amazon_images --verify_images`. These tools never infer an image from review text.

### 5.2 Train and evaluate

```bash
export TRAIN_FILE=/path/to/processed/movies_tv/train.jsonl.gz
export VALID_FILE=/path/to/processed/movies_tv/valid.jsonl.gz
export TEST_FILE=/path/to/processed/movies_tv/test.jsonl.gz
export MODEL_NAME=/path/to/open_llama_7b_v2
export CLIP_PATH=/path/to/clip-vit-base-patch32
export CKPT_DIR=./outputs/movies_tv/seed_42
export DATASET_NAME=MoviesAndTV
bash scripts/run_amazon2023.sh
```

Use the same command with Clothing paths and `DATASET_NAME=ClothingShoesAndJewelry` for the CSJ experiment.

## 6. TripAdvisor

This release does not redistribute TripAdvisor reviews or crawled hotel images. Prepare a local CSV/TSV/JSONL export with user, hotel, rating, review, timestamp, hotel title/description, and image path fields. The converter accepts configurable column names. If the input already contains 20 category labels, pass them in the `category` column or provide `--category_mapping`. If categories are absent, the converter derives 20 deterministic item clusters with SentenceTransformer embeddings and K-means (`seed=42`).

### 6.1 Validate preprocessing with the synthetic sample

```bash
python -u -m camer.tools.prepare_tripadvisor \
  --input_file sample_data/tripadvisor_example.csv \
  --image_dir sample_data \
  --output_dir ./outputs/tripadvisor_sample \
  --k_core 1 --category_col category \
  --split_strategy random_global --seed 42
```

### 6.2 Prepare the real local export

```bash
export TRIPADVISOR_INPUT=/path/to/tripadvisor_reviews.csv
export TRIPADVISOR_IMAGE_DIR=/path/to/hotel_images
export TRIPADVISOR_OUTPUT=/path/to/processed/tripadvisor
bash scripts/prepare_tripadvisor.sh
```

For nonstandard fields, invoke the Python module directly, for example:

```bash
python -u -m camer.tools.prepare_tripadvisor \
  --input_file /path/to/export.csv \
  --image_dir /path/to/hotel_images \
  --output_dir /path/to/processed/tripadvisor \
  --user_col author_id --item_col hotel_id --rating_col score \
  --review_col review --timestamp_col review_date \
  --title_col hotel_name --description_col hotel_description \
  --image_col local_photo_path \
  --k_core 5 --num_categories 20 \
  --split_strategy random_global --seed 42
```

Train and evaluate:

```bash
export TRAIN_FILE=/path/to/processed/tripadvisor/train.jsonl.gz
export VALID_FILE=/path/to/processed/tripadvisor/valid.jsonl.gz
export TEST_FILE=/path/to/processed/tripadvisor/test.jsonl.gz
export MODEL_NAME=/path/to/open_llama_7b_v2
export CLIP_PATH=/path/to/clip-vit-base-patch32
export CKPT_DIR=./outputs/tripadvisor/seed_42
export DATASET_NAME=TripAdvisor
bash scripts/run_tripadvisor.sh
```

The exact dataset counts must be taken from the generated `statistics.json`. If a local source export or image collection differs from the one used in the paper, the resulting counts and scores can differ; this package does not claim that unavailable third-party raw content can be reconstructed from code alone.

## 7. Early stopping and checkpoint selection

`--epochs` is the maximum epoch count. After each epoch, the code evaluates the Eq. (12) validation objective:

```text
selection_loss = rating_mse + 1.0*generation_loss
                 + 0.8*category_contrastive_loss
                 + 1e-3*l2_penalty
```

An improved checkpoint is saved as `best_trainable.pt`. Training stops after three consecutive non-improving epochs by default and reloads the best epoch before test evaluation. Set `EARLY_STOPPING_PATIENCE=1` to stop immediately after the first non-improving epoch, or set it to `0` to disable early stopping. Per-epoch metrics are written to `training_history.json`.

## 8. Ablation studies

Append one ablation flag through a direct Python command or add it to a copied run script:

```text
--no_cmfa    removes category-guided multimodal feature alignment
--no_cmpm    replaces category-aware modality weighting with averaging
--no_cidm    removes category-specific temporal decay
```

All ablations must use the same split, seeds, decoding protocol, and evaluation code as the full model.

## 9. Outputs

Each checkpoint directory contains:

```text
best_trainable.pt
training_history.json
generation_test_beam_results.jsonl
metrics_test_beam.json
```

The evaluator reports RMSE, MAE, FMR, FCR, DIV, USR, BLEU-1, BLEU-4, ROUGE-1, ROUGE-2, and ROUGE-L. `--eval_protocol cier` uses the public CIER/PETER-style unsmoothed BLEU and feature-metric definitions included in this package.

## 10. Reproducibility boundary

This code package supports reproduction of the method and experimental pipeline, but third-party datasets, images, and pretrained model weights must be acquired separately. Do not copy baseline scores from a different preprocessing protocol; rerun every baseline on the same generated splits and targets.
