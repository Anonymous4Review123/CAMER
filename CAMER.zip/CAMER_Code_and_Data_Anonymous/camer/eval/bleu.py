"""
Borrowed from https://github.com/tensorflow/nmt/blob/master/nmt/scripts/bleu.py

Python implementation of BLEU and smooth-BLEU.

This module provides a Python implementation of BLEU and smooth-BLEU.
Smooth BLEU is computed following the method outlined in the paper:
Chin-Yew Lin, Franz Josef Och. ORANGE: a method for evaluating automatic
evaluation metrics for machine translation. COLING 2004.
"""

import collections
import math

# 实现 BLEU（Bilingual Evaluation Understudy）指标计算，用于评估文本生成质量
def _get_ngrams(segment, max_order):
  """Extracts all n-grams upto a given maximum order from an input segment.

  Args:
    segment: text segment from which n-grams will be extracted.
    max_order: maximum length in tokens of the n-grams returned by this
        methods.

  Returns:
    The Counter containing all n-grams upto max_order in segment
    with a count of how many times each n-gram occurred.
  """
  # 提取文本片段中所有1到max_order的n-gram，并计数
  ngram_counts = collections.Counter()
  for order in range(1, max_order + 1):
    for i in range(0, len(segment) - order + 1):
      ngram = tuple(segment[i:i+order])# n-gram以元组形式存储
      ngram_counts[ngram] += 1
  return ngram_counts


def compute_bleu(reference_corpus, translation_corpus, max_order=4,
                 smooth=False):
  """Computes BLEU score of translated segments against one or more references.

  Args:
    reference_corpus: list of lists of references for each translation. Each
        reference should be tokenized into a list of tokens.
    translation_corpus: list of translations to score. Each translation
        should be tokenized into a list of tokens.
    max_order: Maximum n-gram order to use when computing BLEU score.
    smooth: Whether or not to apply Lin et al. 2004 smoothing.

  Returns:
    3-Tuple with the BLEU score, n-gram precisions, geometric mean of n-gram
    precisions and brevity penalty.
  """
  # 计算BLEU分数
  matches_by_order = [0] * max_order # 每个n-gram的匹配数
  possible_matches_by_order = [0] * max_order
  reference_length = 0
  translation_length = 0
  for (references, translation) in zip(reference_corpus,
                                       translation_corpus):
    reference_length += min(len(r) for r in references) # 取最短参考文本长度（BLEU标准）
    translation_length += len(translation)

    # 合并所有参考文本的n-gram（去重）
    merged_ref_ngram_counts = collections.Counter()
    for reference in references:
      merged_ref_ngram_counts |= _get_ngrams(reference, max_order)
    # 生成文本的n-gram
    translation_ngram_counts = _get_ngrams(translation, max_order)
    # 计算重叠的n-gram（匹配数）
    overlap = translation_ngram_counts & merged_ref_ngram_counts
    for ngram in overlap:
      matches_by_order[len(ngram)-1] += overlap[ngram]
    # 计算可能的匹配数（生成文本中n-gram的总数量）
    for order in range(1, max_order+1):
      possible_matches = len(translation) - order + 1
      if possible_matches > 0:
        possible_matches_by_order[order-1] += possible_matches
  # 计算每个n-gram的精度
  precisions = [0] * max_order
  for i in range(0, max_order):
    if smooth:
      # 平滑处理（避免分母为0）
      precisions[i] = ((matches_by_order[i] + 1.) /
                       (possible_matches_by_order[i] + 1.))
    else:
      if possible_matches_by_order[i] > 0:
        precisions[i] = (float(matches_by_order[i]) /
                         possible_matches_by_order[i])
      else:
        precisions[i] = 0.0
  # 计算几何平均精度
  if min(precisions) > 0:
    p_log_sum = sum((1. / max_order) * math.log(p) for p in precisions)
    geo_mean = math.exp(p_log_sum)
  else:
    geo_mean = 0
  # 计算 brevity penalty（长度惩罚，生成文本过短会扣分）
  ratio = float(translation_length) / reference_length

  if ratio > 1.0:
    bp = 1.
  elif ratio ==0:
    bp = 0
  else:
    bp = math.exp(1 - 1. / ratio)# 生成文本越短，惩罚越大

  bleu = geo_mean * bp# 最终BLEU分数

  return (bleu, precisions, bp, ratio, translation_length, reference_length)