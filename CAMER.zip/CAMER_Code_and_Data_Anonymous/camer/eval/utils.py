"""Text, feature and rating metrics used by the experiment entry point."""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, Iterable, List, Sequence, Set, Tuple

from camer.dataset.feature_rules import ASPECT_TERMS, features_in_text, normalize_feature, tokenize
from camer.eval.bleu import compute_bleu
from camer.eval.rouge import rouge


def bleu_score(
    references: Sequence[Sequence[str]],
    generated: Sequence[Sequence[str]],
    n_gram: int = 4,
    smooth: bool = False,
) -> float:
    if not references:
        return 0.0
    formatted = [[list(reference)] for reference in references]
    # CIER calls compute_bleu(..., smooth=False).  Smoothing materially raises
    # BLEU-4 on short explanations, so it must not be changed in a comparable
    # experiment.
    score, *_ = compute_bleu(formatted, [list(value) for value in generated], n_gram, smooth=smooth)
    return float(score * 100.0)


def rouge_score(references: Sequence[str], generated: Sequence[str]) -> Dict[str, float]:
    if not references:
        return {}
    return {key: float(value * 100.0) for key, value in rouge(list(generated), list(references)).items()}


def unique_sentence_percent(sequence_batch: Sequence[Sequence[str]]) -> Tuple[float, int]:
    if not sequence_batch:
        return 0.0, 0
    unique = {tuple(sequence) for sequence in sequence_batch}
    return len(unique) / len(sequence_batch), len(unique)


def _normalize_feature_list(values: Iterable[str]) -> Set[str]:
    return {str(value).strip().lower() for value in values if str(value).strip()}


def feature_metrics(
    predictions: Sequence[str],
    reference_features: Sequence[Sequence[str]],
    liked_aspects: Sequence[str],
    protocol: str = "cier",
) -> Dict[str, float]:
    """Compute standard explanation-feature metrics.

    FMR is the percentage of samples whose generated feature set hits at least
    one ground-truth review feature. FCR is corpus-level reference-feature
    coverage. DIV is average shared generated features per sentence pair, so a
    lower DIV is better.
    """

    reference_sets = [_normalize_feature_list(values) for values in reference_features]
    if protocol == "cier":
        # Exact public CIER/PETER convention: the test feature vocabulary is
        # the set of template[0] values in the test fold.  A generated feature
        # is detected by exact word-token membership; FCR covers that global
        # vocabulary, whereas FMR checks the paired target feature.
        target_features = [
            next((str(value).strip().lower() for value in values if str(value).strip()), "")
            for values in reference_features
        ]
        feature_vocabulary = {value for value in target_features if value}
        prediction_tokens = [set(postprocessing(text.lower()).split()) for text in predictions]
        predicted_sets = [tokens & feature_vocabulary for tokens in prediction_tokens]
        # Public split rows with an empty official feature remain unmatched;
        # they are not silently removed from the metric denominator.
        fmr = sum(bool(feature) and feature in pred for pred, feature in zip(predicted_sets, target_features))
        fmr /= max(1, len(target_features))
        generated_features = set().union(*predicted_sets) if predicted_sets else set()
        fcr = len(generated_features) / max(1, len(feature_vocabulary))
        feature_frequency = Counter(feature for values in predicted_sets for feature in values)
        pair_count = len(predicted_sets) * (len(predicted_sets) - 1) / 2
        shared_count = sum(count * (count - 1) / 2 for count in feature_frequency.values())
        return {
            "FMR": 100.0 * fmr,
            "FCR": 100.0 * fcr,
            "DIV": float(shared_count / max(1.0, pair_count)),
        }

    liked_sets = [
        {normalize_feature(value) for value in str(text).split(",") if normalize_feature(value)}
        for text in liked_aspects
    ]
    vocabulary = set(ASPECT_TERMS)
    for values in reference_sets + liked_sets:
        vocabulary.update(values)
    predicted_sets = [features_in_text(text, vocabulary) for text in predictions]

    valid_refs = [(pred, ref) for pred, ref in zip(predicted_sets, reference_sets) if ref]
    fmr = sum(bool(pred & ref) for pred, ref in valid_refs) / max(1, len(valid_refs))
    all_reference = set().union(*reference_sets) if reference_sets else set()
    generated_reference_hits = set().union(*(pred & ref for pred, ref in zip(predicted_sets, reference_sets))) if predicted_sets else set()
    fcr = len(generated_reference_hits) / max(1, len(all_reference))

    feature_frequency = Counter(feature for values in predicted_sets for feature in values)
    pair_count = len(predicted_sets) * (len(predicted_sets) - 1) / 2
    shared_count = sum(count * (count - 1) / 2 for count in feature_frequency.values())
    diversity = shared_count / max(1.0, pair_count)

    return {
        "FMR": 100.0 * fmr,
        "FCR": 100.0 * fcr,
        "DIV": float(diversity),
    }


def rating_metrics(targets: Sequence[float], predictions: Sequence[float]) -> Dict[str, float]:
    if not targets:
        return {"RMSE": 0.0, "MAE": 0.0}
    errors = [float(prediction) - float(target) for target, prediction in zip(targets, predictions)]
    mse = sum(error * error for error in errors) / len(errors)
    mae = sum(abs(error) for error in errors) / len(errors)
    return {"RMSE": math.sqrt(mse), "MAE": mae}


def postprocessing(text: str) -> str:
    # Byte-for-byte equivalent rules to CIER's public utils.py.  BLEU/ROUGE
    # operate on these whitespace tokens, while the 20-token length limit is
    # imposed earlier by the LLaMA tokenizer.
    text = str(text)
    text = re.sub("'s", " 's", text)
    text = re.sub("'m", " 'm", text)
    text = re.sub("'ve", " 've", text)
    text = re.sub("n't", " n't", text)
    text = re.sub("'re", " 're", text)
    text = re.sub("'d", " 'd", text)
    text = re.sub("'ll", " 'll", text)
    text = re.sub(r"\(", " ( ", text)
    text = re.sub(r"\)", " ) ", text)
    text = re.sub(",+", " , ", text)
    text = re.sub(":+", " , ", text)
    text = re.sub(";+", " . ", text)
    text = re.sub(r"\.+", " . ", text)
    text = re.sub("!+", " ! ", text)
    text = re.sub(r"\?+", " ? ", text)
    return re.sub(" +", " ", text).strip()
