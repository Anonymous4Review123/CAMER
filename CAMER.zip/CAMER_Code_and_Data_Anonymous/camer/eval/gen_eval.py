"""Generate explanations and evaluate them with reproducible metrics."""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional

import torch
from tqdm import tqdm

from camer.eval.utils import (
    bleu_score,
    feature_metrics,
    rating_metrics,
    rouge_score,
    unique_sentence_percent,
    postprocessing,
)


def _move_tensors(batch: Dict[str, Any], device: torch.device) -> Dict[str, Any]:
    return {key: value.to(device) if torch.is_tensor(value) else value for key, value in batch.items()}


@torch.no_grad()
def generate_and_eval(model, loader, device, args, save_path: Optional[str] = None) -> Dict[str, float]:
    model.eval()
    predictions, references = [], []
    reference_features, liked_aspects = [], []
    rating_targets, rating_predictions, rows = [], [], []

    for batch in tqdm(loader, desc="Generate"):
        batch = _move_tensors(batch, device)
        _, prefix_source, rating_context, predicted_ratings, _, diagnostics = model(
            clip_input_ids=batch["clip_input_ids"],
            clip_attention_mask=batch["clip_attention_mask"],
            pixel_values=batch["pixel_values"],
            image_mask=batch["image_mask"],
            cat_ids=batch["cat_ids"],
            history_clip_input_ids=batch["history_clip_input_ids"],
            history_clip_attention_mask=batch["history_clip_attention_mask"],
            history_pixel_values=batch["history_pixel_values"],
            history_image_mask=batch["history_image_mask"],
            history_time_gaps=batch["history_time_gaps"],
            history_item_mask=batch["history_item_mask"],
            history_category_ids=batch["history_category_ids"],
            target_interval=batch["target_interval"],
            users=batch["users"],
            items=batch["items"],
        )
        predicted_ratings = predicted_ratings.clamp(1.0, 5.0)
        generated_ids = model.generate_with_prefix(
            prefix_source,
            batch["llm_input_ids"],
            batch["llm_attention_mask"],
            max_new_tokens=args.max_new_tokens,
            min_new_tokens=args.min_new_tokens,
            decoding_strategy=args.decoding_strategy,
            num_beams=args.num_beams,
            temperature=args.temperature,
            top_p=args.top_p,
            top_k=args.top_k,
            penalty_alpha=args.penalty_alpha,
            contrastive_top_k=args.contrastive_top_k,
            length_penalty=args.length_penalty,
            repetition_penalty=args.repetition_penalty,
            no_repeat_ngram_size=args.no_repeat_ngram_size,
        )
        generated_texts = [
            text.strip() for text in model.tokenizer.batch_decode(generated_ids, skip_special_tokens=True)
        ]

        rating_targets.extend(batch["ratings"].detach().cpu().tolist())
        rating_predictions.extend(predicted_ratings.detach().cpu().tolist())
        for index, prediction in enumerate(generated_texts):
            reference = batch["references"][index]
            predictions.append(prediction)
            references.append(reference)
            reference_features.append(batch["reference_features"][index])
            liked_aspects.append(batch["liked_aspects"][index])
            rows.append(
                {
                    "user_id": batch["raw_user_ids"][index],
                    "item_id": batch["raw_item_ids"][index],
                    "item_name": batch["item_names"][index],
                    "category": batch["categories"][index],
                    "prediction": prediction,
                    "reference": reference,
                    "reference_features": batch["reference_features"][index],
                    "liked_aspects": batch["liked_aspects"][index],
                    "rating_true": float(batch["ratings"][index].item()),
                    "rating_pred": float(predicted_ratings[index].item()),
                    "user_text_weight": float(diagnostics["user_modality_weights"][index, 0].item()),
                    "user_visual_weight": float(diagnostics["user_modality_weights"][index, 1].item()),
                    "category_decay_rate": float(diagnostics["category_decay_rate"][index].item()),
                }
            )

    # Match the public CIER/PETER-style evaluator: punctuation is separated
    # before whitespace tokenization.  BPE controls model length, not BLEU's
    # word-level n-gram definition.
    predicted_tokens = [postprocessing(text.lower()).split() for text in predictions]
    reference_tokens = [postprocessing(text.lower()).split() for text in references]
    metrics: Dict[str, float] = {
        "BLEU-1": bleu_score(reference_tokens, predicted_tokens, 1, smooth=False),
        "BLEU-4": bleu_score(reference_tokens, predicted_tokens, 4, smooth=False),
    }
    rouge_metrics = rouge_score(references, predictions)
    metrics.update(rouge_metrics)
    metrics["ROUGE-1"] = rouge_metrics.get("rouge_1/r_score", 0.0)
    metrics["ROUGE-2"] = rouge_metrics.get("rouge_2/r_score", 0.0)
    metrics["ROUGE-L"] = rouge_metrics.get("rouge_l/f_score", 0.0)
    metrics.update(feature_metrics(predictions, reference_features, liked_aspects, protocol=args.eval_protocol))
    metrics["USR"] = 100.0 * unique_sentence_percent(predicted_tokens)[0]
    metrics.update(rating_metrics(rating_targets, rating_predictions))

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        with open(save_path, "w", encoding="utf-8") as handle:
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False) + "\n")
        with open(save_path + ".metrics.json", "w", encoding="utf-8") as handle:
            json.dump(metrics, handle, ensure_ascii=False, indent=2, sort_keys=True)
    return metrics
