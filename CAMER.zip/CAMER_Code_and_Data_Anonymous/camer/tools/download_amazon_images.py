"""Resume-safe Amazon metadata image downloader for the experiment items only.

Existing valid ASIN-named images are skipped.  Missing images are downloaded
atomically and converted to RGB JPEG.  The tool never deletes an existing
file, and rerunning it retries only unresolved items.
"""

from __future__ import annotations

import argparse
import gzip
import io
import json
import os
import pickle
import socket
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Set, Tuple

from PIL import Image


IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")
URL_PRIORITY = ("hi_res", "large", "720w", "480w", "360w", "thumb")


def _load_wanted(args: argparse.Namespace) -> Set[str]:
    wanted: Set[str] = set()
    if args.sentires_pickle:
        with open(args.sentires_pickle, "rb") as handle:
            rows = pickle.load(handle)
        if hasattr(rows, "to_dict"):
            rows = rows.to_dict("records")
        for row in rows:
            item = row.get("item") or row.get("item_id") or row.get("asin") or row.get("parent_asin")
            if item is not None and str(item).strip():
                wanted.add(str(item).strip())
    if args.wanted_file:
        with open(args.wanted_file, "r", encoding="utf-8") as handle:
            wanted.update(line.strip() for line in handle if line.strip())
    if not wanted:
        raise RuntimeError("provide --sentires_pickle or --wanted_file with at least one item")
    return wanted


def _valid_existing(image_dir: Path, item: str) -> Optional[Path]:
    for extension in IMAGE_EXTENSIONS:
        path = image_dir / f"{item}{extension}"
        if not path.is_file() or path.stat().st_size <= 0:
            continue
        try:
            with Image.open(path) as image:
                image.verify()
            return path
        except Exception:
            # Do not delete user data. A new valid .jpg may be written beside
            # an invalid file with another extension.
            continue
    return None


def _pick_url(record: Dict[str, Any]) -> Optional[str]:
    images = record.get("images") or []
    if not isinstance(images, list):
        return None
    ordered = sorted(images, key=lambda value: str(value.get("variant", "")).upper() != "MAIN")
    for image in ordered:
        if not isinstance(image, dict):
            continue
        for key in URL_PRIORITY:
            value = image.get(key)
            if isinstance(value, str) and value.startswith(("http://", "https://")):
                return value
    return None


def _scan_metadata(path: str, wanted: Set[str]) -> Tuple[Dict[str, str], int]:
    urls: Dict[str, str] = {}
    lines = 0
    opener = gzip.open if str(path).endswith(".gz") else open
    try:
        with opener(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                lines += 1
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                item = record.get("parent_asin") or record.get("asin") or record.get("item")
                item = str(item).strip() if item is not None else ""
                if not item or item not in wanted or item in urls:
                    continue
                url = _pick_url(record)
                if url:
                    urls[item] = url
    except EOFError as exc:
        raise RuntimeError(
            f"metadata gzip is incomplete after {lines} lines; redownload/copy the complete file before continuing"
        ) from exc
    return urls, lines


def _download_one(
    item: str,
    url: str,
    image_dir: Path,
    timeout: float,
    retries: int,
    max_edge: int,
) -> Dict[str, Any]:
    existing = _valid_existing(image_dir, item)
    if existing:
        return {"item": item, "status": "skipped_existing", "path": str(existing)}
    destination = image_dir / f"{item}.jpg"
    error = "unknown error"
    for attempt in range(1, retries + 2):
        temporary = image_dir / f".{item}.{os.getpid()}.{attempt}.part"
        try:
            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (compatible; CUPA-ER research image fetcher/1.0)",
                    "Accept": "image/avif,image/webp,image/png,image/jpeg,*/*;q=0.8",
                },
            )
            with urllib.request.urlopen(request, timeout=timeout) as response:
                payload = response.read(25 * 1024 * 1024 + 1)
            if len(payload) > 25 * 1024 * 1024:
                raise RuntimeError("image exceeds 25 MiB safety limit")
            with Image.open(io.BytesIO(payload)) as image:
                image = image.convert("RGB")
                image.thumbnail((max_edge, max_edge), Image.Resampling.LANCZOS)
                image.save(temporary, format="JPEG", quality=90, optimize=True)
            os.replace(temporary, destination)
            return {
                "item": item,
                "status": "downloaded",
                "path": str(destination),
                "source_url": url,
            }
        except (OSError, RuntimeError, socket.timeout, urllib.error.URLError) as exc:
            error = f"{type(exc).__name__}: {exc}"
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
    return {"item": item, "status": "failed", "error": error, "source_url": url}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--meta_file", required=True)
    parser.add_argument("--image_dir", required=True)
    parser.add_argument("--sentires_pickle", default=None)
    parser.add_argument("--wanted_file", default=None)
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--timeout", type=float, default=20.0)
    parser.add_argument("--retries", type=int, default=2)
    parser.add_argument("--max_edge", type=int, default=768)
    parser.add_argument("--max_downloads", type=int, default=None, help="debug limit after existing files are skipped")
    parser.add_argument("--dry_run", action="store_true")
    args = parser.parse_args()

    image_dir = Path(args.image_dir)
    image_dir.mkdir(parents=True, exist_ok=True)
    wanted = _load_wanted(args)
    urls, scanned = _scan_metadata(args.meta_file, wanted)
    existing = {item for item in wanted if _valid_existing(image_dir, item)}
    pending = [(item, urls[item]) for item in sorted(wanted - existing) if item in urls]
    if args.max_downloads is not None:
        pending = pending[: max(0, args.max_downloads)]
    summary = {
        "wanted_items": len(wanted),
        "metadata_lines_scanned": scanned,
        "metadata_image_urls": len(urls),
        "skipped_existing": len(existing),
        "missing_metadata_or_url": len(wanted - set(urls) - existing),
        "pending": len(pending),
    }
    print(json.dumps(summary, ensure_ascii=False), flush=True)
    if args.dry_run:
        return

    manifest = image_dir / "download_manifest.jsonl"
    counts = {"downloaded": 0, "skipped_existing": len(existing), "failed": 0}
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as executor, manifest.open(
        "a", encoding="utf-8"
    ) as log:
        futures = {
            executor.submit(
                _download_one, item, url, image_dir, args.timeout, args.retries, args.max_edge
            ): item
            for item, url in pending
        }
        for completed, future in enumerate(as_completed(futures), start=1):
            result = future.result()
            counts[result["status"]] = counts.get(result["status"], 0) + 1
            log.write(json.dumps(result, ensure_ascii=False) + "\n")
            log.flush()
            if completed % 100 == 0 or completed == len(futures):
                print(json.dumps({"completed": completed, **counts}, ensure_ascii=False), flush=True)

    final_valid = sum(_valid_existing(image_dir, item) is not None for item in wanted)
    print(json.dumps({"final_valid_images": final_valid, **counts}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
