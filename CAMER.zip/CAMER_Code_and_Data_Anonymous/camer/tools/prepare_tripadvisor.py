"""Prepare TripAdvisor interactions for CAMER.

The converter accepts CSV/TSV or JSONL/JSONL.GZ exports, normalizes them to the
same schema used by the Amazon preprocessing pipeline, optionally derives 20
item categories with sentence embeddings and K-means, applies iterative k-core
filtering, resolves locally stored hotel images, and writes fixed train/valid/
test splits.

The script does not crawl or redistribute TripAdvisor content. Users must
obtain data and images under the source site's terms and pass local paths.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import gzip
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

from camer.dataset.feature_rules import extract_phrase_features

IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".bmp")


def _clean_text(value: Any) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def _timestamp(value: Any) -> int:
    if value is None or value == "":
        return 0
    try:
        number = float(value)
        if number > 1e11:
            number /= 1000.0
        return max(0, int(number))
    except (TypeError, ValueError, OverflowError):
        pass
    parsed = pd.to_datetime(value, errors="coerce", utc=True)
    if pd.isna(parsed):
        return 0
    return int(parsed.timestamp())


def _open_text(path: Path):
    return gzip.open(path, "rt", encoding="utf-8") if path.suffix == ".gz" else path.open("r", encoding="utf-8")


def _iter_rows(path: Path, delimiter: Optional[str]) -> Iterator[Dict[str, Any]]:
    lower = path.name.lower()
    if lower.endswith((".jsonl", ".jsonl.gz")):
        with _open_text(path) as handle:
            for line in handle:
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(row, dict):
                    yield row
        return

    if delimiter is None:
        delimiter = "\t" if lower.endswith((".tsv", ".tsv.gz")) else ","
    with _open_text(path) as handle:
        reader = csv.DictReader(handle, delimiter=delimiter)
        for row in reader:
            yield dict(row)


def _column(row: Mapping[str, Any], configured: str, aliases: Sequence[str]) -> Any:
    for key in (configured, *aliases):
        if key and key in row and row[key] not in (None, ""):
            return row[key]
    return None


def _first_sentence(text: str) -> str:
    parts = [part.strip() for part in re.split(r"(?<=[.!?])\s+", text) if part.strip()]
    for part in parts:
        if len(part.split()) >= 3:
            return part
    return text


def _resolve_image(item_id: str, raw_path: str, image_dir: Optional[Path], input_dir: Path) -> str:
    candidates: List[Path] = []
    if raw_path:
        raw = Path(raw_path).expanduser()
        candidates.extend([raw, input_dir / raw])
        if image_dir is not None:
            candidates.append(image_dir / raw.name)
    if image_dir is not None:
        safe_ids = [item_id, re.sub(r"[^A-Za-z0-9._-]+", "_", item_id)]
        for safe_id in safe_ids:
            for ext in IMAGE_EXTENSIONS:
                candidates.append(image_dir / f"{safe_id}{ext}")
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate.resolve())
    return ""


def _load_category_mapping(path: Optional[Path]) -> Dict[str, str]:
    if path is None:
        return {}
    mapping: Dict[str, str] = {}
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): _clean_text(v) for k, v in data.items() if _clean_text(v)}
        raise ValueError("JSON category mapping must be an item_id -> category object")
    with _open_text(path) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            item = _clean_text(row.get("item_id") or row.get("item"))
            category = _clean_text(row.get("category"))
            if item and category:
                mapping[item] = category
    return mapping


def _iterative_k_core(frame: pd.DataFrame, k: int) -> pd.DataFrame:
    if k <= 1:
        return frame.reset_index(drop=True)
    current = frame
    while True:
        user_counts = current["user_id"].value_counts()
        item_counts = current["item"].value_counts()
        keep = current["user_id"].isin(user_counts[user_counts >= k].index) & current["item"].isin(item_counts[item_counts >= k].index)
        updated = current.loc[keep].copy()
        if len(updated) == len(current):
            return updated.reset_index(drop=True)
        if updated.empty:
            raise RuntimeError(f"{k}-core filtering removed all interactions")
        current = updated


def _derive_categories(frame: pd.DataFrame, num_categories: int, model_name: str, seed: int) -> Dict[str, str]:
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError("sentence-transformers is required when categories are absent") from exc

    item_texts: Dict[str, List[str]] = defaultdict(list)
    for row in frame.itertuples(index=False):
        text = " ".join(value for value in (row.item_name, row.description, row.review_text) if value)
        if text and len(item_texts[row.item]) < 5:
            item_texts[row.item].append(text)
    items = sorted(item_texts)
    if len(items) < num_categories:
        raise ValueError(f"num_categories={num_categories} exceeds the number of retained items={len(items)}")
    texts = [" ".join(item_texts[item])[:2000] for item in items]
    encoder = SentenceTransformer(model_name)
    vectors = encoder.encode(texts, batch_size=64, show_progress_bar=True, normalize_embeddings=True)
    labels = KMeans(n_clusters=num_categories, random_state=seed, n_init=10).fit_predict(vectors)
    return {item: f"TripAdvisorCluster_{int(label):02d}" for item, label in zip(items, labels)}


def _split_global(frame: pd.DataFrame, valid_ratio: float, test_ratio: float, seed: int) -> Dict[str, pd.DataFrame]:
    shuffled = frame.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    n = len(shuffled)
    n_valid = max(1, int(round(n * valid_ratio)))
    n_test = max(1, int(round(n * test_ratio)))
    if n_valid + n_test >= n:
        raise RuntimeError("Not enough rows for non-empty train/valid/test splits")
    n_train = n - n_valid - n_test
    return {"train": shuffled.iloc[:n_train], "valid": shuffled.iloc[n_train:n_train+n_valid], "test": shuffled.iloc[n_train+n_valid:]}


def _split_by_user(frame: pd.DataFrame, valid_ratio: float, test_ratio: float, seed: int, temporal: bool) -> Dict[str, pd.DataFrame]:
    buckets: Dict[str, List[Dict[str, Any]]] = {"train": [], "valid": [], "test": []}
    for user_id, group in frame.groupby("user_id", sort=True):
        group = group.sort_values(["timestamp", "item"]) if temporal else group.sample(frac=1.0, random_state=seed + sum(ord(c) for c in str(user_id)))
        rows = group.to_dict("records")
        if len(rows) < 3:
            buckets["train"].extend(rows)
            continue
        n_valid = max(1, int(round(len(rows) * valid_ratio)))
        n_test = max(1, int(round(len(rows) * test_ratio)))
        if n_valid + n_test >= len(rows):
            n_valid = n_test = 1
        n_train = len(rows) - n_valid - n_test
        buckets["train"].extend(rows[:n_train])
        buckets["valid"].extend(rows[n_train:n_train+n_valid])
        buckets["test"].extend(rows[n_train+n_valid:])
    return {name: pd.DataFrame(rows, columns=frame.columns) for name, rows in buckets.items()}


def _write_jsonl(frame: pd.DataFrame, path: Path) -> None:
    with gzip.open(path, "wt", encoding="utf-8") as handle:
        for row in frame.to_dict("records"):
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--image_dir", default=None)
    parser.add_argument("--category_mapping", default=None, help="Optional JSON/CSV item-to-category mapping")
    parser.add_argument("--delimiter", default=None, help="CSV delimiter; inferred from .csv/.tsv when omitted")
    parser.add_argument("--user_col", default="user_id")
    parser.add_argument("--item_col", default="item_id")
    parser.add_argument("--rating_col", default="rating")
    parser.add_argument("--review_col", default="review_text")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--title_col", default="item_name")
    parser.add_argument("--description_col", default="description")
    parser.add_argument("--category_col", default="category")
    parser.add_argument("--image_col", default="image_path")
    parser.add_argument("--k_core", type=int, default=5)
    parser.add_argument("--min_review_words", type=int, default=5)
    parser.add_argument("--max_review_words", type=int, default=100)
    parser.add_argument("--valid_ratio", type=float, default=0.1)
    parser.add_argument("--test_ratio", type=float, default=0.1)
    parser.add_argument("--split_strategy", choices=("random_global", "random_user", "temporal"), default="random_global")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_categories", type=int, default=20)
    parser.add_argument("--category_embedding_model", default="sentence-transformers/all-MiniLM-L6-v2")
    parser.add_argument("--require_image", action=argparse.BooleanOptionalAction, default=True)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    input_path = Path(args.input_file).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    image_dir = Path(args.image_dir).expanduser().resolve() if args.image_dir else None
    category_mapping = _load_category_mapping(Path(args.category_mapping).expanduser().resolve() if args.category_mapping else None)
    output_dir.mkdir(parents=True, exist_ok=True)

    records: List[Dict[str, Any]] = []
    for index, raw in enumerate(_iter_rows(input_path, args.delimiter)):
        user_id = _clean_text(_column(raw, args.user_col, ("user", "reviewerID", "uid")))
        item_id = _clean_text(_column(raw, args.item_col, ("item", "hotel_id", "asin", "iid")))
        review_text = _clean_text(_column(raw, args.review_col, ("review", "text", "content")))
        try:
            rating = float(_column(raw, args.rating_col, ("overall", "score")))
        except (TypeError, ValueError):
            continue
        words = review_text.split()
        if not user_id or not item_id or not (1.0 <= rating <= 5.0) or not (args.min_review_words <= len(words) <= args.max_review_words):
            continue
        raw_image = _clean_text(_column(raw, args.image_col, ("image", "photo_path")))
        image_path = _resolve_image(item_id, raw_image, image_dir, input_path.parent)
        if args.require_image and not image_path:
            continue
        category = _clean_text(_column(raw, args.category_col, ("cluster", "hotel_category"))) or category_mapping.get(item_id, "")
        explanation = _first_sentence(review_text)
        _, features, _ = extract_phrase_features(explanation, topk=5, max_ngram=2)
        records.append({
            "user_id": user_id,
            "item": item_id,
            "rating": rating,
            "timestamp": _timestamp(_column(raw, args.timestamp_col, ("date", "review_date", "unixReviewTime"))),
            "review_text": review_text,
            "explanation_text": explanation,
            "review_features": features,
            "official_feature": False,
            "item_name": _clean_text(_column(raw, args.title_col, ("title", "hotel_name", "name"))) or item_id,
            "description": _clean_text(_column(raw, args.description_col, ("hotel_description", "summary")))[:500],
            "category": category,
            "image_path": image_path,
            "source_index": index,
        })

    if not records:
        raise RuntimeError("No valid interactions were retained; inspect column names, word limits, ratings and image paths")
    frame = pd.DataFrame(records).sort_values(["user_id", "item", "timestamp", "source_index"]).drop_duplicates(["user_id", "item"], keep="last")
    frame = _iterative_k_core(frame, args.k_core)

    if (frame["category"].str.len() == 0).any():
        derived = _derive_categories(frame, args.num_categories, args.category_embedding_model, args.seed)
        frame.loc[frame["category"].str.len() == 0, "category"] = frame.loc[frame["category"].str.len() == 0, "item"].map(derived)
    if (frame["category"].str.len() == 0).any():
        raise RuntimeError("Some items still have no category")

    if args.split_strategy == "random_global":
        splits = _split_global(frame, args.valid_ratio, args.test_ratio, args.seed)
    else:
        splits = _split_by_user(frame, args.valid_ratio, args.test_ratio, args.seed, temporal=args.split_strategy == "temporal")
    if any(split.empty for split in splits.values()):
        raise RuntimeError("A generated split is empty")

    columns = ["user_id", "item", "rating", "timestamp", "review_text", "explanation_text", "review_features", "official_feature", "item_name", "description", "category", "image_path", "source_index"]
    for name, split in splits.items():
        _write_jsonl(split[columns], output_dir / f"{name}.jsonl.gz")
    _write_jsonl(pd.concat(list(splits.values()), ignore_index=True)[columns], output_dir / "all_cleaned.jsonl.gz")

    users = sorted(frame["user_id"].unique().tolist())
    items = sorted(frame["item"].unique().tolist())
    categories = sorted(frame["category"].unique().tolist())
    mappings = {
        "user2id": {value: index for index, value in enumerate(users)},
        "item2id": {value: index for index, value in enumerate(items)},
        "category2id": {value: index for index, value in enumerate(categories)},
    }
    statistics = {
        "dataset": "TripAdvisor",
        "num_users": len(users),
        "num_items": len(items),
        "num_interactions": int(len(frame)),
        "num_categories": len(categories),
        "category_distribution": dict(Counter(frame["category"]).most_common()),
        "k_core": args.k_core,
        "split_strategy": args.split_strategy,
        "seed": args.seed,
        "split_counts": {name: int(len(split)) for name, split in splits.items()},
        "image_interaction_coverage": float((frame["image_path"].str.len() > 0).mean()),
        "note": "Images and raw TripAdvisor content are not redistributed by this package.",
    }
    (output_dir / "mappings.json").write_text(json.dumps(mappings, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "statistics.json").write_text(json.dumps(statistics, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(statistics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
