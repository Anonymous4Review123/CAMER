"""Export cleaned Amazon item IDs and attach downloaded images safely.

The raw cleaner may run with ``--no-require_image`` so expensive k-core
filtering finishes before image download. This tool completes the multimodal
pipeline in two reproducible phases:

1. Export only item IDs surviving deduplication and iterative k-core.
2. After ``download_amazon_images.py`` finishes, update SQLite metadata and
   atomically rewrite train/valid/test/all_cleaned JSONL.GZ image paths.

Only static item IDs and Amazon metadata images are used. Review or explanation
text is never used to select an image, so this step introduces no target-text
leakage.
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import sqlite3
from pathlib import Path
from typing import Dict, Iterable, Iterator, Optional, Set, Tuple

from PIL import Image


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
DATASET_FILES = ("train.jsonl.gz", "valid.jsonl.gz", "test.jsonl.gz", "all_cleaned.jsonl.gz")


def valid_image(path: Path, verify: bool = False) -> bool:
    if not path.is_file() or path.stat().st_size <= 0 or path.suffix.lower() not in IMAGE_EXTENSIONS:
        return False
    if not verify:
        return True
    try:
        with Image.open(path) as image:
            image.verify()
        return True
    except Exception:
        return False


def require_finished_reviews(connection: sqlite3.Connection) -> None:
    has_progress = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='ingest_progress'"
    ).fetchone()
    if not has_progress:
        return
    rows = connection.execute(
        "SELECT committed_line, completed FROM ingest_progress WHERE stage LIKE 'reviews:%'"
    ).fetchall()
    if rows and not all(bool(row[1]) for row in rows):
        checkpoint = max(int(row[0]) for row in rows)
        raise RuntimeError(
            f"review ingestion is incomplete at raw line {checkpoint:,}; "
            "finish prepare_amazon.py before exporting formal image IDs"
        )


def cleaned_items(connection: sqlite3.Connection) -> Set[str]:
    return {
        str(row[0])
        for row in connection.execute("SELECT DISTINCT item_id FROM reviews ORDER BY item_id")
        if row[0] is not None and str(row[0]).strip()
    }


def atomic_write_lines(path: Path, values: Iterable[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        for value in values:
            handle.write(str(value) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def scan_images(image_dir: Path, wanted: Set[str], verify: bool) -> Dict[str, str]:
    found: Dict[str, str] = {}
    if not image_dir.is_dir():
        raise FileNotFoundError(image_dir)
    for path in image_dir.iterdir():
        if path.stem not in wanted or path.stem in found:
            continue
        if valid_image(path, verify=verify):
            found[path.stem] = str(path.resolve())
    return found


def update_database(connection: sqlite3.Connection, images: Dict[str, str]) -> int:
    connection.execute("DROP TABLE IF EXISTS temp.image_updates")
    connection.execute(
        "CREATE TEMP TABLE image_updates (item_id TEXT PRIMARY KEY, image_path TEXT NOT NULL)"
    )
    connection.executemany(
        "INSERT INTO image_updates(item_id, image_path) VALUES (?, ?)",
        images.items(),
    )
    connection.execute(
        """
        UPDATE metadata
        SET image_path=(
            SELECT image_updates.image_path
            FROM image_updates
            WHERE image_updates.item_id=metadata.item_id
        )
        WHERE item_id IN (SELECT item_id FROM image_updates)
        """
    )
    changed = int(connection.execute("SELECT changes()").fetchone()[0])
    connection.commit()
    return changed


def rewrite_jsonl_gz(path: Path, images: Dict[str, str]) -> Tuple[int, int]:
    if not path.is_file():
        raise FileNotFoundError(path)
    temporary = path.with_name(path.name + ".images.tmp.gz")
    total = with_image = 0
    try:
        with gzip.open(path, "rt", encoding="utf-8") as source, gzip.open(
            temporary, "wt", encoding="utf-8"
        ) as target:
            for line_number, line in enumerate(source, 1):
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise RuntimeError(f"{path}: invalid JSON at line {line_number}") from exc
                item = row.get("item") or row.get("parent_asin") or row.get("asin")
                item = str(item).strip() if item is not None else ""
                attached = images.get(item)
                if attached:
                    row["image_path"] = attached
                else:
                    existing = Path(str(row.get("image_path") or ""))
                    if not valid_image(existing, verify=False):
                        row["image_path"] = ""
                total += 1
                with_image += int(bool(row.get("image_path")))
                target.write(json.dumps(row, ensure_ascii=False) + "\n")
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return total, with_image


def update_statistics(output_dir: Path, report: Dict[str, object]) -> None:
    path = output_dir / "statistics.json"
    payload: Dict[str, object] = {}
    if path.is_file():
        payload = json.loads(path.read_text(encoding="utf-8"))
    payload["image_attachment"] = report
    payload["image_protocol"] = (
        "static Amazon metadata images matched by item ID only; "
        "no review/explanation-text image retrieval"
    )
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work_db", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--image_dir", required=True)
    parser.add_argument("--wanted_file", required=True)
    parser.add_argument(
        "--export_only",
        action="store_true",
        help="Only write surviving k-core item IDs for the downloader",
    )
    parser.add_argument(
        "--verify_images",
        action="store_true",
        help="Decode every image before attachment (safer but slower)",
    )
    parser.add_argument(
        "--min_image_coverage",
        type=float,
        default=0.0,
        help="Fail before rewriting JSONL if item coverage is below this 0..1 threshold",
    )
    args = parser.parse_args()
    if not 0.0 <= args.min_image_coverage <= 1.0:
        parser.error("--min_image_coverage must be between 0 and 1")

    work_db = Path(args.work_db)
    output_dir = Path(args.output_dir)
    image_dir = Path(args.image_dir)
    wanted_file = Path(args.wanted_file)
    if not work_db.is_file():
        raise FileNotFoundError(work_db)
    connection = sqlite3.connect(work_db)
    try:
        require_finished_reviews(connection)
        wanted = cleaned_items(connection)
        if not wanted:
            raise RuntimeError("the cleaned reviews table contains no surviving items")
        atomic_write_lines(wanted_file, sorted(wanted))
        print(json.dumps({"wanted_items": len(wanted), "wanted_file": str(wanted_file.resolve())}))
        if args.export_only:
            return

        images = scan_images(image_dir, wanted, verify=args.verify_images)
        item_coverage = len(images) / len(wanted)
        if item_coverage < args.min_image_coverage:
            raise RuntimeError(
                f"image item coverage {item_coverage:.4%} is below required "
                f"{args.min_image_coverage:.4%}; JSONL files were not modified"
            )
        database_rows_updated = update_database(connection, images)
        split_report: Dict[str, Dict[str, object]] = {}
        for filename in DATASET_FILES:
            total, with_image = rewrite_jsonl_gz(output_dir / filename, images)
            split_report[filename] = {
                "rows": total,
                "rows_with_image": with_image,
                "interaction_image_coverage": with_image / max(1, total),
            }
        report: Dict[str, object] = {
            "wanted_items": len(wanted),
            "valid_images": len(images),
            "item_image_coverage": item_coverage,
            "database_rows_updated": database_rows_updated,
            "image_dir": str(image_dir.resolve()),
            "splits": split_report,
        }
        update_statistics(output_dir, report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
    finally:
        connection.close()


if __name__ == "__main__":
    main()
