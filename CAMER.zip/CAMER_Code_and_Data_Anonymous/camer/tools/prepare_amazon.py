"""Prepare a leakage-safe Amazon explainable-recommendation benchmark.

The script streams JSONL/JSONL.GZ files into SQLite, matches metadata and real
images, deduplicates user-item pairs, applies iterative k-core filtering,
normalizes domain categories, and writes fixed train/valid/test
files. It is designed for the full Amazon Reviews 2023 files without loading
millions of reviews into a pandas DataFrame.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import random
import re
import sqlite3
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from camer.dataset.feature_rules import extract_phrase_features, features_in_text
from camer.tools.category_cleaning import primary_category


NAVIGATION_TAGS = {
    "all sony pictures titles", "all titles", "blu-ray", "boxed sets", "dvd", "featured categories",
    "genre for featured categories", "movies", "movies & tv", "studio specials",
}

def infer_domain(*paths: str) -> str:
    joined = " ".join(str(path).lower() for path in paths)
    if "clothing" in joined or "shoes_and_jewelry" in joined:
        return "clothing"
    return "movies_tv"


def smart_open(path: str, mode: str = "rt"):
    if str(path).endswith(".gz"):
        return gzip.open(path, mode, encoding=None if "b" in mode else "utf-8")
    return open(path, mode, encoding=None if "b" in mode else "utf-8")


def iter_jsonl(path: str) -> Iterator[Dict[str, Any]]:
    with smart_open(path, "rt") as handle:
        for line_number, line in enumerate(handle, 1):
            try:
                value = json.loads(line)
            except (json.JSONDecodeError, TypeError):
                continue
            if isinstance(value, dict):
                yield value


def iter_jsonl_with_line_number(
    path: str, start_after_line: int = 0
) -> Iterator[Tuple[int, Dict[str, Any]]]:
    """Stream JSONL records after a durable raw-line checkpoint.

    For gzip inputs Python still has to decompress preceding bytes, but skipped
    lines are not JSON-decoded or inserted into SQLite.  The checkpoint is a
    physical one-based line number, so malformed/blank rows cannot make resume
    positions drift between runs.
    """
    with smart_open(path, "rt") as handle:
        for line_number, line in enumerate(handle, 1):
            if line_number <= start_after_line:
                continue
            try:
                value = json.loads(line)
            except (json.JSONDecodeError, TypeError):
                continue
            if isinstance(value, dict):
                yield line_number, value


def normalize_timestamp(value: Any) -> int:
    try:
        timestamp = float(value)
        if timestamp > 1e11:
            timestamp /= 1000.0
        return max(0, int(timestamp))
    except (TypeError, ValueError, OverflowError):
        return 0


def select_explanation_sentence(review_text: str) -> str:
    """Choose one aspect-bearing sentence as the explanation supervision.

    This function is used only to create the target/reference.  Its result is
    never copied into a prompt or user profile for the same interaction.
    """
    text = flatten_text(review_text)
    sentences = [part.strip() for part in re.split(r"(?<=[.!?])\s+|[\r\n]+", text) if part.strip()]
    candidates: List[Tuple[int, int, int, str]] = []
    for index, sentence in enumerate(sentences):
        length = len(re.findall(r"[A-Za-z0-9]+", sentence))
        if not 4 <= length <= 60:
            continue
        aspect_count = len(features_in_text(sentence))
        # Prefer feature-bearing, compact sentences; preserve early-position
        # order as the final deterministic tie breaker.
        candidates.append((aspect_count, -abs(length - 16), -index, sentence))
    if candidates:
        return max(candidates)[3]
    return text


def flatten_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return re.sub(r"\s+", " ", value).strip()
    if isinstance(value, dict):
        return " ".join(filter(None, (flatten_text(item) for item in value.values())))
    if isinstance(value, (list, tuple, set)):
        return " ".join(filter(None, (flatten_text(item) for item in value)))
    return str(value).strip()


def flatten_categories(value: Any) -> List[str]:
    values: List[str] = []
    if isinstance(value, str):
        values.append(value)
    elif isinstance(value, dict):
        for item in value.values():
            values.extend(flatten_categories(item))
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            values.extend(flatten_categories(item))
    cleaned: List[str] = []
    for value in values:
        normalized = re.sub(r"\s+", " ", value).strip()
        if normalized and normalized.lower() not in NAVIGATION_TAGS and normalized not in cleaned:
            cleaned.append(normalized)
    return cleaned


def canonical_category(
    raw_categories: Iterable[str],
    title: str = "",
    features: str = "",
    description: str = "",
    domain: str = "movies_tv",
) -> Tuple[str, Dict[str, Any]]:
    """Clean static category fields without title/review inference or clustering."""
    raw_values = list(raw_categories)
    label = primary_category(raw_values, domain)
    return label, {
        "source": "static_category_cleaning",
        "raw_categories": raw_values,
        "uses_title_or_review": False,
        "uses_tfidf_or_kmeans": False,
    }


def find_image(image_dir: Path, item_id: str) -> Optional[str]:
    for extension in (".jpg", ".jpeg", ".png", ".webp"):
        candidate = image_dir / f"{item_id}{extension}"
        if candidate.is_file() and candidate.stat().st_size > 0:
            return str(candidate.resolve())
    return None


def get_item_id(record: Dict[str, Any]) -> Optional[str]:
    value = record.get("parent_asin") or record.get("asin") or record.get("item")
    value = str(value).strip() if value is not None else ""
    return value or None


def get_user_id(record: Dict[str, Any]) -> Optional[str]:
    value = record.get("user_id") or record.get("reviewerID") or record.get("user")
    value = str(value).strip() if value is not None else ""
    return value or None


def initialize_database(connection: sqlite3.Connection) -> None:
    connection.executescript(
        """
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        PRAGMA temp_store=FILE;
        CREATE TABLE IF NOT EXISTS metadata (
            item_id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            raw_categories TEXT NOT NULL,
            category_evidence TEXT NOT NULL DEFAULT '{}',
            image_path TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS reviews (
            user_id TEXT NOT NULL,
            item_id TEXT NOT NULL,
            rating REAL NOT NULL,
            timestamp INTEGER NOT NULL,
            review_text TEXT NOT NULL,
            split_key INTEGER NOT NULL,
            PRIMARY KEY (user_id, item_id)
        );
        CREATE TABLE IF NOT EXISTS ingest_progress (
            stage TEXT PRIMARY KEY,
            source_path TEXT NOT NULL,
            committed_line INTEGER NOT NULL DEFAULT 0,
            completed INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """
    )
    columns = {row[1] for row in connection.execute("PRAGMA table_info(reviews)")}
    if "split_key" not in columns:
        connection.execute("ALTER TABLE reviews ADD COLUMN split_key INTEGER NOT NULL DEFAULT 0")
    metadata_columns = {row[1] for row in connection.execute("PRAGMA table_info(metadata)")}
    if "category_evidence" not in metadata_columns:
        connection.execute("ALTER TABLE metadata ADD COLUMN category_evidence TEXT NOT NULL DEFAULT '{}'")
    connection.commit()


def progress_stage(stage: str, source_path: str) -> str:
    """Bind a progress record to both its logical stage and source file."""
    return f"{stage}:{Path(source_path).expanduser().resolve()}"


def read_progress(
    connection: sqlite3.Connection, stage: str, source_path: str
) -> Tuple[int, bool]:
    key = progress_stage(stage, source_path)
    row = connection.execute(
        "SELECT source_path, committed_line, completed FROM ingest_progress WHERE stage=?",
        (key,),
    ).fetchone()
    if row is None:
        return 0, False
    expected = str(Path(source_path).expanduser().resolve())
    if row[0] != expected:
        raise RuntimeError(f"resume source mismatch for {stage}: {row[0]} != {expected}")
    return int(row[1]), bool(row[2])


def write_progress(
    connection: sqlite3.Connection,
    stage: str,
    source_path: str,
    committed_line: int,
    completed: bool = False,
) -> None:
    key = progress_stage(stage, source_path)
    resolved = str(Path(source_path).expanduser().resolve())
    connection.execute(
        """
        INSERT INTO ingest_progress
            (stage, source_path, committed_line, completed, updated_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(stage) DO UPDATE SET
            source_path=excluded.source_path,
            committed_line=excluded.committed_line,
            completed=excluded.completed,
            updated_at=CURRENT_TIMESTAMP
        """,
        (key, resolved, int(committed_line), int(completed)),
    )


def bootstrap_progress(
    connection: sqlite3.Connection,
    stage: str,
    source_path: str,
    requested_line: Optional[int],
) -> Tuple[int, bool]:
    committed_line, completed = read_progress(connection, stage, source_path)
    if requested_line is not None:
        if committed_line > 0 or completed:
            print(
                f"[{stage.upper()}] ignoring bootstrap line {requested_line:,}; "
                f"database checkpoint already exists at {committed_line:,}"
            )
        else:
            write_progress(
                connection, stage, source_path, int(requested_line), completed=False
            )
            connection.commit()
            committed_line = int(requested_line)
            print(f"[{stage.upper()}] bootstrapped checkpoint at raw line {committed_line:,}")
    return committed_line, completed


def commit_batch_and_progress(
    connection: sqlite3.Connection,
    sql: str,
    batch: Sequence[Sequence[Any]],
    stage: str,
    source_path: str,
    committed_line: int,
    completed: bool = False,
) -> None:
    """Atomically commit data rows and the line checkpoint."""
    if batch:
        connection.executemany(sql, batch)
    write_progress(
        connection,
        stage,
        source_path,
        committed_line=committed_line,
        completed=completed,
    )
    connection.commit()


def load_metadata(connection: sqlite3.Connection, args: argparse.Namespace) -> set[str]:
    image_dir = Path(args.image_dir)
    insert_sql = """
        INSERT OR REPLACE INTO metadata
        (item_id, title, description, category, raw_categories, category_evidence, image_path)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """
    batch: List[Tuple[str, str, str, str, str, str, str]] = []
    existing_metadata = connection.execute("SELECT COUNT(*) FROM metadata").fetchone()[0]
    if args.resume_meta_line and existing_metadata == 0:
        raise RuntimeError(
            "--resume_meta_line is non-zero but the metadata table is empty; "
            "refusing to skip source rows"
        )
    checkpoint, completed = bootstrap_progress(
        connection,
        "metadata",
        args.meta_file,
        args.resume_meta_line,
    )
    if completed:
        valid_items = {row[0] for row in connection.execute("SELECT item_id FROM metadata")}
        print(
            f"[META] already complete at raw line {checkpoint:,}; "
            f"matched_items={len(valid_items):,}"
        )
        return valid_items

    scanned = checkpoint
    kept = existing_metadata
    last_seen_line = checkpoint
    print(f"[META] resuming after raw line {checkpoint:,}; existing_items={kept:,}")
    for line_number, record in iter_jsonl_with_line_number(args.meta_file, checkpoint):
        scanned = line_number
        last_seen_line = line_number
        item_id = get_item_id(record)
        if not item_id:
            pass
        else:
            image_path = find_image(image_dir, item_id)
            if not args.require_image or image_path is not None:
                title = flatten_text(record.get("title") or record.get("item_name") or item_id)
                description = flatten_text(
                    record.get("description") or record.get("features") or record.get("details") or ""
                )[: args.max_description_chars]
                raw_categories = flatten_categories(
                    [record.get("categories"), record.get("category"), record.get("main_category")]
                )
                category, category_evidence = canonical_category(
                    raw_categories,
                    title=title,
                    features=flatten_text(record.get("features")),
                    description=description,
                    domain=args.domain,
                )
                batch.append(
                    (
                        item_id,
                        title or item_id,
                        description,
                        category,
                        json.dumps(raw_categories, ensure_ascii=False),
                        json.dumps(category_evidence, ensure_ascii=False),
                        image_path or "",
                    )
                )
                kept += 1
        if scanned % args.sqlite_batch_size == 0:
            commit_batch_and_progress(
                connection, insert_sql, batch, "metadata", args.meta_file, scanned
            )
            batch.clear()
        if scanned % args.log_every == 0:
            print(f"[META] scanned={scanned:,} kept={kept:,}")
    commit_batch_and_progress(
        connection,
        insert_sql,
        batch,
        "metadata",
        args.meta_file,
        last_seen_line,
        completed=True,
    )
    if args.semantic_backfill:
        semantic_backfill_categories(connection, args)
    valid_items = {row[0] for row in connection.execute("SELECT item_id FROM metadata")}
    print(f"[META] finished: scanned={scanned:,} matched_items={len(valid_items):,}")
    return valid_items


def semantic_backfill_categories(connection: sqlite3.Connection, args: argparse.Namespace) -> None:
    """Removed in v12: Amazon categories must come from static metadata only."""
    raise RuntimeError(
        "Amazon semantic backfill is disabled: do not infer categories from text or clustering"
    )
def load_reviews(connection: sqlite3.Connection, valid_items: set[str], args: argparse.Namespace) -> None:
    upsert_sql = """
        INSERT INTO reviews (user_id, item_id, rating, timestamp, review_text, split_key)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(user_id, item_id) DO UPDATE SET
            rating=excluded.rating,
            timestamp=excluded.timestamp,
            review_text=excluded.review_text
            ,split_key=excluded.split_key
        WHERE excluded.timestamp >= reviews.timestamp
    """
    existing_reviews = connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    if args.resume_review_line and existing_reviews == 0:
        raise RuntimeError(
            "--resume_review_line is non-zero but the reviews table is empty; "
            "refusing to skip source rows"
        )
    checkpoint, completed = bootstrap_progress(
        connection,
        "reviews",
        args.review_file,
        args.resume_review_line,
    )
    if completed:
        deduplicated = connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
        print(
            f"[REVIEWS] already complete at raw line {checkpoint:,}; "
            f"deduplicated={deduplicated:,}"
        )
        return

    batch: List[Tuple[str, str, float, int, str, int]] = []
    scanned = checkpoint
    valid = 0
    last_seen_line = checkpoint
    print(f"[REVIEWS] resuming after raw line {checkpoint:,}")
    stopped_at_limit = False
    for line_number, record in iter_jsonl_with_line_number(args.review_file, checkpoint):
        if args.max_raw_records and line_number > args.max_raw_records:
            stopped_at_limit = True
            break
        scanned = line_number
        last_seen_line = line_number
        user_id, item_id = get_user_id(record), get_item_id(record)
        if user_id and item_id and item_id in valid_items:
            try:
                rating = float(record.get("rating", record.get("overall", 0)))
            except (TypeError, ValueError):
                rating = 0.0
            timestamp = normalize_timestamp(record.get("timestamp", record.get("unixReviewTime", 0)))
            review_text = flatten_text(record.get("text") or record.get("review_text") or record.get("review") or "")
            word_count = len(re.findall(r"[A-Za-z0-9]+", review_text))
            if 1.0 <= rating <= 5.0 and timestamp > 0 and args.min_review_words <= word_count <= args.max_review_words:
                digest = hashlib.blake2b(
                    f"{args.seed}|{user_id}|{item_id}|{timestamp}".encode("utf-8"), digest_size=8
                ).digest()
                split_key = int.from_bytes(digest, "big") & ((1 << 63) - 1)
                batch.append((user_id, item_id, rating, timestamp, review_text, split_key))
                valid += 1
        if scanned % args.sqlite_batch_size == 0:
            commit_batch_and_progress(
                connection, upsert_sql, batch, "reviews", args.review_file, scanned
            )
            batch.clear()
        if scanned % args.log_every == 0:
            print(f"[REVIEWS] scanned={scanned:,} valid_before_dedup={valid:,}")
    reached_end = not stopped_at_limit
    commit_batch_and_progress(
        connection,
        upsert_sql,
        batch,
        "reviews",
        args.review_file,
        last_seen_line,
        completed=reached_end,
    )
    deduplicated = connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    print(f"[REVIEWS] finished: scanned={scanned:,} deduplicated={deduplicated:,}")


def iterative_k_core(connection: sqlite3.Connection, k: int) -> None:
    connection.execute("CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id)")
    connection.execute("CREATE INDEX IF NOT EXISTS idx_reviews_item ON reviews(item_id)")
    connection.commit()
    iteration = 0
    while True:
        iteration += 1
        before = connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
        connection.execute(
            "DELETE FROM reviews WHERE user_id IN "
            "(SELECT user_id FROM reviews GROUP BY user_id HAVING COUNT(*) < ?)",
            (k,),
        )
        connection.execute(
            "DELETE FROM reviews WHERE item_id IN "
            "(SELECT item_id FROM reviews GROUP BY item_id HAVING COUNT(*) < ?)",
            (k,),
        )
        connection.commit()
        after = connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
        print(f"[K-CORE] iteration={iteration} before={before:,} after={after:,}")
        if after == before:
            break
        if after == 0:
            raise RuntimeError("k-core filtering removed every interaction; lower --k_core or check image/meta matching")


def split_sizes(count: int, valid_ratio: float, test_ratio: float) -> Tuple[int, int, int]:
    if count < 3:
        return count, 0, 0
    valid_count = max(1, int(round(count * valid_ratio)))
    test_count = max(1, int(round(count * test_ratio)))
    if valid_count + test_count >= count:
        valid_count, test_count = 1, 1
    return count - valid_count - test_count, valid_count, test_count


def write_group(
    rows: List[sqlite3.Row],
    writers: Dict[str, Any],
    args: argparse.Namespace,
    category_counts: Counter[str],
    split_counts: Counter[str],
) -> None:
    if args.split_strategy == "random_user":
        # Stable per-user random split: every retained user still contributes
        # training interactions, while the same seed always reproduces files.
        stable_user_seed = sum((index + 1) * ord(char) for index, char in enumerate(str(rows[0][0])))
        rows = list(rows)
        random.Random(args.seed + stable_user_seed).shuffle(rows)
    train_count, valid_count, _ = split_sizes(len(rows), args.valid_ratio, args.test_ratio)
    for index, row in enumerate(rows):
        split = "train" if index < train_count else "valid" if index < train_count + valid_count else "test"
        write_row(row, split, writers, args, category_counts, split_counts)


def write_row(
    row: sqlite3.Row,
    split: str,
    writers: Dict[str, Any],
    args: argparse.Namespace,
    category_counts: Counter[str],
    split_counts: Counter[str],
) -> None:
    explanation_text = select_explanation_sentence(row[4])
    _, review_features, _ = extract_phrase_features(
        explanation_text, topk=args.review_feature_topk, max_ngram=2
    )
    raw_categories = json.loads(row[8]) if row[8] else []
    category_evidence = json.loads(row[9]) if row[9] else {}
    sample = {
        "user_id": row[0],
        "item": row[1],
        "rating": float(row[2]),
        "timestamp": int(row[3]),
        "review_text": row[4],
        "explanation_text": explanation_text,
        "review_features": review_features,
        "item_name": row[5],
        "description": row[6],
        "category": row[7],
        "raw_categories": raw_categories,
        "category_evidence": category_evidence,
        "image_path": row[10],
    }
    line = json.dumps(sample, ensure_ascii=False) + "\n"
    writers[split].write(line)
    writers["all"].write(line)
    category_counts[row[7]] += 1
    split_counts[split] += 1


def export_dataset(connection: sqlite3.Connection, args: argparse.Namespace) -> Dict[str, Any]:
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "train": output_dir / "train.jsonl.gz",
        "valid": output_dir / "valid.jsonl.gz",
        "test": output_dir / "test.jsonl.gz",
        "all": output_dir / "all_cleaned.jsonl.gz",
    }
    writers = {name: gzip.open(path, "wt", encoding="utf-8") for name, path in paths.items()}
    category_counts: Counter[str] = Counter()
    split_counts: Counter[str] = Counter()
    base_query = """
        SELECT r.user_id, r.item_id, r.rating, r.timestamp, r.review_text,
               m.title, m.description, m.category, m.raw_categories, m.category_evidence, m.image_path,
               r.split_key
        FROM reviews r JOIN metadata m ON r.item_id = m.item_id
    """
    current_user: Optional[str] = None
    group: List[sqlite3.Row] = []
    try:
        if args.split_strategy == "random_global":
            interaction_count = connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
            train_count, valid_count, _ = split_sizes(interaction_count, args.valid_ratio, args.test_ratio)
            query = base_query + " ORDER BY r.split_key, r.user_id, r.item_id"
            for index, row in enumerate(connection.execute(query)):
                split = "train" if index < train_count else "valid" if index < train_count + valid_count else "test"
                write_row(row, split, writers, args, category_counts, split_counts)
        else:
            query = base_query + " ORDER BY r.user_id, r.timestamp, r.item_id"
            for row in connection.execute(query):
                if current_user is not None and row[0] != current_user:
                    write_group(group, writers, args, category_counts, split_counts)
                    group = []
                current_user = row[0]
                group.append(row)
            if group:
                write_group(group, writers, args, category_counts, split_counts)
    finally:
        for writer in writers.values():
            writer.close()

    users = [row[0] for row in connection.execute("SELECT DISTINCT user_id FROM reviews ORDER BY user_id")]
    items = [row[0] for row in connection.execute("SELECT DISTINCT item_id FROM reviews ORDER BY item_id")]
    interactions = connection.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    category_source_distribution = dict(
        connection.execute(
            "SELECT COALESCE(json_extract(m.category_evidence, '$.source'), 'legacy'), COUNT(*) "
            "FROM reviews r JOIN metadata m ON r.item_id=m.item_id GROUP BY 1 ORDER BY 2 DESC"
        ).fetchall()
    )
    mappings = {
        "user2id": {value: index for index, value in enumerate(users)},
        "item2id": {value: index for index, value in enumerate(items)},
        "category2id": {
            value: index for index, value in enumerate(sorted(category_counts))
        },
    }
    statistics = {
        "num_users": len(users),
        "num_items": len(items),
        "num_interactions": interactions,
        "num_categories": len(category_counts),
        "category_distribution": dict(category_counts.most_common()),
        "category_source_distribution": category_source_distribution,
        "category_protocol": "static metadata cleaning only; no text inference or clustering",
        "domain": args.domain,
        "k_core": args.k_core,
        "split_strategy": args.split_strategy,
        "seed": args.seed,
        "split": {"train": 1.0 - args.valid_ratio - args.test_ratio, "valid": args.valid_ratio, "test": args.test_ratio},
        "split_counts": {name: split_counts[name] for name in ("train", "valid", "test")},
        "files": {name: str(path.resolve()) for name, path in paths.items()},
    }
    with open(output_dir / "mappings.json", "w", encoding="utf-8") as handle:
        json.dump(mappings, handle, ensure_ascii=False, indent=2)
    with open(output_dir / "statistics.json", "w", encoding="utf-8") as handle:
        json.dump(statistics, handle, ensure_ascii=False, indent=2)
    return statistics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--review_file", required=True)
    parser.add_argument("--meta_file", required=True)
    parser.add_argument("--image_dir", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument(
        "--domain",
        choices=["auto", "movies_tv", "clothing"],
        default="auto",
        help="auto infers from file names; each domain uses deterministic category cleaning",
    )
    parser.add_argument("--work_db", default=None, help="SQLite work file; defaults to OUTPUT_DIR/prepare.sqlite")
    parser.add_argument("--k_core", type=int, default=5)
    parser.add_argument("--min_review_words", type=int, default=5)
    parser.add_argument("--max_review_words", type=int, default=100)
    parser.add_argument("--max_description_chars", type=int, default=500)
    parser.add_argument("--review_feature_topk", type=int, default=5)
    parser.add_argument(
        "--semantic_backfill",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Deprecated; keep disabled because v12 uses static category cleaning only",
    )
    parser.add_argument("--valid_ratio", type=float, default=0.1)
    parser.add_argument("--test_ratio", type=float, default=0.1)
    parser.add_argument(
        "--split_strategy",
        choices=["random_global", "random_user", "temporal"],
        default="random_global",
        help="random_global matches the paper; random_user keeps every user represented; temporal is stricter",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--sqlite_batch_size", type=int, default=5000)
    parser.add_argument("--log_every", type=int, default=200000)
    parser.add_argument("--max_raw_records", type=int, default=None, help="Debug only; omit for formal experiments")
    parser.add_argument("--require_image", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument(
        "--resume_meta_line",
        type=int,
        default=None,
        help="One-time bootstrap for a legacy partial DB without ingest_progress; do not guess",
    )
    parser.add_argument(
        "--resume_review_line",
        type=int,
        default=None,
        help="One-time bootstrap for a legacy partial DB without ingest_progress; do not guess",
    )
    args = parser.parse_args()
    if args.domain == "auto":
        args.domain = infer_domain(args.review_file, args.meta_file, args.output_dir)
    if args.valid_ratio <= 0 or args.test_ratio <= 0 or args.valid_ratio + args.test_ratio >= 1:
        parser.error("valid_ratio and test_ratio must be positive and sum to less than 1")
    if args.resume_meta_line is not None and args.resume_meta_line < 0:
        parser.error("--resume_meta_line must be non-negative")
    if args.resume_review_line is not None and args.resume_review_line < 0:
        parser.error("--resume_review_line must be non-negative")
    if args.rebuild and (args.resume_meta_line or args.resume_review_line):
        parser.error("--rebuild cannot be combined with non-zero resume bootstrap lines")
    return args


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    database_path = Path(args.work_db) if args.work_db else output_dir / "prepare.sqlite"
    if args.rebuild and database_path.exists():
        database_path.unlink()
    connection = sqlite3.connect(database_path)
    connection.row_factory = sqlite3.Row
    initialize_database(connection)
    try:
        valid_items = load_metadata(connection, args)
        if not valid_items:
            raise RuntimeError("No metadata rows matched the requested image policy")
        load_reviews(connection, valid_items, args)
        iterative_k_core(connection, args.k_core)
        statistics = export_dataset(connection, args)
        print(json.dumps(statistics, ensure_ascii=False, indent=2))
    finally:
        connection.close()


if __name__ == "__main__":
    main()
