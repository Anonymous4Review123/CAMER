"""Deterministic, auditable category cleaning for Amazon metadata.

This module deliberately contains no TF-IDF, embedding classifier, KMeans, or
review-text inference.  A product category is obtained only from the static
``categories``/``category`` fields in Amazon metadata.  Store-navigation and
publisher/distributor labels are removed, spelling variants are merged, and a
fold-specific vocabulary is fitted from training items by ``prepare_sentires``.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple


OTHER_MOVIES = "Other Movies & TV"
OTHER_CLOTHING = "Other Clothing"


_NOISE_EXACT = {
    "all titles", "all sony pictures titles", "arts, entertainment, and culture",
    "blu-ray", "boxed sets", "disc on demand", "dvd", "featured categories",
    "featured deals & new releases", "first to know", "fully loaded dvds",
    "genre for featured categories", "movies", "movies & tv", "movies & tv holiday wishlist",
    "prime video", "studio specials", "today's deals", "widescreen",
}

_NOISE_PATTERNS = (
    re.compile(r"\bhome entertainment\b", re.I),
    re.compile(r"\bhome video\b", re.I),
    re.compile(r"\bdvd store\b", re.I),
    re.compile(r"\bnews network\b", re.I),
    re.compile(r"\bchannel\b", re.I),
)


# Ordered rules are used only to merge synonymous raw metadata labels.  They
# do not inspect title, description, review, explanation, rating, or split.
MOVIES_RULES: Sequence[Tuple[str, Sequence[str]]] = (
    ("Action & Adventure", (r"action", r"adventure", r"action & adventure")),
    ("Animation", (r"animation", r"animated")),
    ("Anime", (r"anime", r"anime & manga")),
    ("Art House & International", (r"arthouse", r"art house & international", r"indie & art house")),
    ("Classics", (r"classics?", r"criterion collection")),
    ("Comedy", (r"comed(?:y|ies)", r"stand[- ]?up")),
    ("Cult Movies", (r"cult movies?",)),
    ("Documentary", (r"documentar(?:y|ies)", r"non[- ]?fiction")),
    ("Drama", (r"drama", r"dramas")),
    ("Educational", (r"educational", r"instructional")),
    ("Exercise & Fitness", (r"exercise & fitness", r"fitness", r"fitness & yoga", r"yoga")),
    ("Faith & Spirituality", (r"faith & spirituality", r"faith and spirituality", r"christian movies? & tv", r"christian video")),
    ("Fantasy", (r"fantasy",)),
    ("Foreign & International", (r"foreign films?", r"international")),
    ("Historical", (r"historical",)),
    ("Holidays & Seasonal", (r"holidays? & seasonal",)),
    ("Horror", (r"horror", r"slasher", r"zombie")),
    ("Kids & Family", (r"kids", r"kids & family", r"family", r"3-6 years", r"7-9 years")),
    ("LGBTQ+", (r"lgbt", r"lgbtq")),
    ("Military & War", (r"military & war", r"military and war", r"war")),
    ("Music & Concerts", (r"music artists", r"music videos? & concerts", r"music videos? and concerts", r"concerts?")),
    ("Musicals & Performing Arts", (r"musicals?", r"musicals? & performing arts", r"performing arts")),
    ("Mystery", (r"mystery",)),
    ("Reality & Unscripted", (r"reality tv", r"unscripted")),
    ("Romance", (r"romance", r"romantic")),
    ("Science Fiction", (r"science fiction", r"sci[- ]?fi", r"science fiction & fantasy", r"sci[- ]?fi & fantasy")),
    ("Special Interests", (r"special interest", r"special interests")),
    ("Sports", (r"sports?",)),
    ("Suspense & Thriller", (r"suspense", r"thrillers?", r"mystery & suspense", r"mystery & thrillers")),
    ("Talk Shows & Variety", (r"talk show and variety",)),
    ("Television", (r"tv", r"television", r"made-for-tv movies", r"miniseries", r"characters & series")),
    ("Westerns", (r"western", r"westerns")),
    ("Young Adult", (r"young adult audience",)),
)


CLOTHING_RULES: Sequence[Tuple[str, Sequence[str]]] = (
    ("Baby Clothing", (r"baby", r"infant", r"newborn", r"layette")),
    ("Boys' Clothing", (r"boys", r"boys' clothing")),
    ("Girls' Clothing", (r"girls", r"girls' clothing")),
    ("Men's Clothing", (r"men", r"men's clothing", r"mens")),
    ("Women's Clothing", (r"women", r"women's clothing", r"womens")),
    ("Maternity", (r"maternity", r"nursing")),
    ("Plus-Size Clothing", (r"plus[- ]?size", r"big & tall", r"big and tall")),
    ("Activewear", (r"activewear", r"athletic", r"sportswear")),
    ("Coats & Jackets", (r"coats?", r"jackets?", r"outerwear")),
    ("Dresses", (r"dresses?",)),
    ("Pants & Jeans", (r"pants", r"jeans", r"trousers")),
    ("Shirts & Tops", (r"shirts?", r"tops", r"blouses?", r"t-shirts?")),
    ("Skirts", (r"skirts?",)),
    ("Suits", (r"suits?", r"blazers?")),
    ("Lingerie & Underwear", (r"lingerie", r"bras?", r"panties", r"underwear")),
    ("Sleepwear", (r"sleepwear", r"pajamas?", r"nightgowns?")),
    ("Swimwear", (r"swimwear", r"swimsuits?", r"bikinis?")),
    ("Shoes", (r"shoes?", r"boots?", r"sandals?", r"sneakers?", r"slippers?", r"heels?")),
    ("Jewelry", (r"jewelry", r"necklaces?", r"earrings?", r"bracelets?", r"rings?")),
    ("Watches", (r"watches?", r"watch bands?")),
    ("Handbags & Wallets", (r"handbags?", r"purses?", r"wallets?", r"clutches?", r"tote bags?")),
    ("Accessories", (r"accessories", r"belts?", r"scarves", r"gloves?", r"hats?", r"sunglasses", r"ties")),
    ("Costumes", (r"costumes?", r"cosplay", r"halloween")),
    ("Workwear & Uniforms", (r"workwear", r"uniforms?", r"scrubs")),
    ("Traditional & Cultural Wear", (r"traditional", r"cultural", r"kimono", r"sari")),
    ("Luggage & Travel Gear", (r"luggage", r"suitcases?", r"travel bags?")),
)


def _normalise(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _flatten(value: Any) -> List[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, Mapping):
        result: List[str] = []
        for item in value.values():
            result.extend(_flatten(item))
        return result
    if isinstance(value, (list, tuple, set)):
        result = []
        for item in value:
            result.extend(_flatten(item))
        return result
    return []


def clean_category_candidates(raw_categories: Any, domain: str) -> List[str]:
    """Return ordered canonical labels from static raw metadata only."""
    rules = CLOTHING_RULES if domain == "clothing" else MOVIES_RULES
    labels: List[str] = []
    for raw in _flatten(raw_categories):
        text = _normalise(raw)
        lower = text.lower().replace("’", "'")
        if not lower or lower in _NOISE_EXACT or any(pattern.search(text) for pattern in _NOISE_PATTERNS):
            continue
        for label, patterns in rules:
            if any(re.fullmatch(pattern, lower, flags=re.I) for pattern in patterns):
                if label not in labels:
                    labels.append(label)
                break
    return labels


def primary_category(raw_categories: Any, domain: str) -> str:
    candidates = clean_category_candidates(raw_categories, domain)
    if candidates:
        return candidates[0]
    return OTHER_CLOTHING if domain == "clothing" else OTHER_MOVIES


def fit_fold_vocabulary(
    train_labels: Iterable[str], domain: str, min_count: int = 20, max_categories: int = 40
) -> Tuple[List[str], Dict[str, int]]:
    """Fit a deterministic category vocabulary from the training fold only."""
    fallback = OTHER_CLOTHING if domain == "clothing" else OTHER_MOVIES
    counts = Counter(label for label in train_labels if label and label != fallback)
    ordered = sorted(counts, key=lambda label: (-counts[label], label))
    kept = [label for label in ordered if counts[label] >= min_count][: max(1, max_categories - 1)]
    kept.append(fallback)
    return kept, {label: int(counts.get(label, 0)) for label in kept}


def map_to_vocabulary(label: str, vocabulary: Iterable[str], domain: str) -> str:
    allowed = set(vocabulary)
    if label in allowed:
        return label
    return OTHER_CLOTHING if domain == "clothing" else OTHER_MOVIES

