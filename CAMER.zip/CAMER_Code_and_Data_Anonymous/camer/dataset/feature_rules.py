"""Shared aspect/feature extraction rules for preprocessing and evaluation."""

from __future__ import annotations

import re
from collections import Counter
from typing import Iterable, List, Set, Tuple

WORD_RE = re.compile(r"[a-z0-9]+(?:'[a-z0-9]+)?", re.I)

STOPWORDS = {
    "a", "about", "after", "again", "all", "also", "am", "an", "and", "any", "are", "as", "at",
    "be", "because", "been", "before", "being", "but", "by", "can", "could", "did", "do", "does",
    "doing", "for", "from", "get", "got", "had", "has", "have", "having", "he", "her", "here",
    "hers", "him", "his", "how", "i", "if", "in", "into", "is", "it", "its", "just", "me",
    "more", "most", "my", "no", "not", "of", "on", "or", "other", "our", "ours", "out", "over",
    "really", "she", "so", "some", "such", "than", "that", "the", "their", "theirs", "them",
    "then", "there", "these", "they", "this", "those", "to", "too", "up", "very", "was", "we",
    "were", "what", "when", "where", "which", "while", "who", "why", "will", "with", "would",
    "you", "your", "yours", "amazon", "product", "item", "movie", "film", "show", "watch", "watched",
}

# Common explainable-recommendation aspects. The extractor is intentionally
# shared by data preparation and evaluation so that FMR/FCR use one vocabulary.
ASPECT_TERMS = {
    "acting", "action", "animation", "appearance", "audio", "battery", "cast", "character", "characters",
    "clean", "cleanliness", "color", "comfort", "comfortable", "comedy", "design", "dialogue", "direction",
    "durability", "effects", "ending", "entertaining", "fit", "fun", "funny", "graphics", "humor", "image",
    "location", "material", "music", "pacing", "performance", "plot", "price", "quality", "room", "service",
    "size", "sound", "staff", "story", "style", "value", "visual", "writing",
    "fabric", "sizing", "length", "waist", "stretch", "softness", "breathability", "warmth", "weight",
    "stitching", "seam", "zipper", "buttons", "pockets", "heel", "sole", "support", "clasp", "chain",
    "shine", "shape", "coverage", "thickness", "washability",
}


def normalize_feature(value: str) -> str:
    tokens = [m.group(0).lower() for m in WORD_RE.finditer(str(value or ""))]
    return " ".join(tokens).strip()


def tokenize(text: str) -> List[str]:
    return [
        token
        for token in (m.group(0).lower() for m in WORD_RE.finditer(str(text or "")))
        if len(token) > 2 and token not in STOPWORDS
    ]


def extract_phrase_features(
    text: str,
    topk: int = 5,
    max_ngram: int = 2,
) -> Tuple[Set[str], List[str], List[Tuple[str, int]]]:
    """Extract compact aspect phrases without using the current sample elsewhere."""
    tokens = tokenize(text)
    if not tokens:
        return set(), [], []

    scores: Counter[str] = Counter()
    max_ngram = max(1, min(int(max_ngram), 3))
    for index, token in enumerate(tokens):
        # Unigrams that look like known aspects receive a strong score. Other
        # content words remain candidates so domain-specific evidence is kept.
        scores[token] += 4 if token in ASPECT_TERMS else 1
        for ngram_size in range(2, max_ngram + 1):
            if index + ngram_size > len(tokens):
                continue
            phrase_tokens = tokens[index:index + ngram_size]
            phrase = " ".join(phrase_tokens)
            aspect_hits = sum(word in ASPECT_TERMS for word in phrase_tokens)
            scores[phrase] += 2 + 3 * aspect_hits

    ranked = sorted(scores.items(), key=lambda pair: (-pair[1], len(pair[0].split()), pair[0]))
    selected = [phrase for phrase, _ in ranked[:max(1, int(topk))]]
    return set(selected), selected, ranked[:max(1, int(topk))]


def features_in_text(text: str, feature_vocabulary: Iterable[str] = ASPECT_TERMS) -> Set[str]:
    """Find complete normalized feature phrases in generated text."""
    normalized_text = f" {normalize_feature(text)} "
    found: Set[str] = set()
    for feature in feature_vocabulary:
        normalized = normalize_feature(feature)
        if normalized and f" {normalized} " in normalized_text:
            found.add(normalized)
    return found
