"""Dataset package.

The heavy torch/transformers dataloader is intentionally not imported here so
the standalone streaming cleaner can run in a lightweight preprocessing
environment.
"""

__all__ = ["DashDataManager", "MyCollater", "MyDataset", "compute_global_rating_mean"]


def __getattr__(name):
    if name in __all__:
        from .dataloader import DashDataManager, MyCollater, MyDataset, compute_global_rating_mean

        return {
            "DashDataManager": DashDataManager,
            "MyCollater": MyCollater,
            "MyDataset": MyDataset,
            "compute_global_rating_mean": compute_global_rating_mean,
        }[name]
    raise AttributeError(name)
