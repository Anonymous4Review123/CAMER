"""Clean-data loader and collator for personalized explanation generation."""

from __future__ import annotations

import datetime
import gzip
import json
import math
import os
import random
import re
from bisect import bisect_left
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset, Sampler

from camer.dataset.feature_rules import extract_phrase_features, normalize_feature


def smart_open(path: str):
    return gzip.open(path, "rt", encoding="utf-8") if str(path).endswith(".gz") else open(path, "r", encoding="utf-8")


def normalize_timestamp(value: Any) -> int:
    try:
        timestamp = float(value)
        if timestamp > 1e11:
            timestamp /= 1000.0
        return max(0, int(timestamp))
    except (TypeError, ValueError, OverflowError):
        return 0


def ts_to_month_bin(timestamp: Any, time_bins: int = 400) -> int:
    try:
        dt = datetime.datetime.fromtimestamp(normalize_timestamp(timestamp))
        month_id = (dt.year - 2000) * 12 + dt.month - 1
        return max(0, min(time_bins - 1, month_id))
    except (OverflowError, OSError, ValueError):
        return 0


def _text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _features(value: Any, fallback_text: str = "", topk: int = 5) -> List[str]:
    if isinstance(value, str):
        candidates = [part.strip() for part in value.split(",")]
    elif isinstance(value, (list, tuple, set)):
        candidates = [str(part).strip() for part in value]
    else:
        candidates = []
    normalized = []
    for candidate in candidates:
        feature = normalize_feature(candidate)
        if feature and feature not in normalized:
            normalized.append(feature)
    if normalized:
        return normalized[:topk]
    return extract_phrase_features(fallback_text, topk=topk, max_ngram=2)[1]


class DashDataManager:
    """Load fixed cleaned splits and build one consistent ID mapping."""

    def __init__(
        self,
        train_file: Optional[str] = None,
        valid_file: Optional[str] = None,
        test_file: Optional[str] = None,
        data_file: Optional[str] = None,
        dataset_name: str = "amazon",
        debug_max_samples: Optional[int] = None,
    ):
        self.dataset_name = dataset_name
        self.user2id: Dict[str, int] = {"<UNK_USER>": 0}
        self.item2id: Dict[str, int] = {"<UNK_ITEM>": 0}
        self.category2id: Dict[str, int] = {"Unknown": 0}
        self.item_info: Dict[str, Dict[str, Any]] = {}

        if train_file:
            self.train_records = self._load_file(train_file, debug_max_samples)
            self.valid_records = self._load_file(valid_file, debug_max_samples) if valid_file else []
            self.test_records = self._load_file(test_file, debug_max_samples) if test_file else []
        elif data_file:
            all_records = self._load_file(data_file, debug_max_samples)
            self.train_records, self.valid_records, self.test_records = self._temporal_split(all_records)
        else:
            raise ValueError("Provide --train_file (recommended) or --data_file")

        if not self.train_records or not self.valid_records or not self.test_records:
            raise RuntimeError("A train/valid/test split is empty. Run prepare_amazon.py without a tiny debug limit.")

        # Embedding vocabularies are fitted on training IDs only. Validation
        # and test IDs are never used to size or define learned ID tables.
        for record in self.train_records:
            user_id, item_id, category = record["user_id"], record["item"], record["category"]
            if user_id not in self.user2id:
                self.user2id[user_id] = len(self.user2id)
            if item_id not in self.item2id:
                self.item2id[item_id] = len(self.item2id)
            if category not in self.category2id:
                self.category2id[category] = len(self.category2id)
            self.item_info.setdefault(
                item_id,
                {
                    "item_name": record["item_name"],
                    "description": record["description"],
                    "category": category,
                    "image_path": record["image_path"],
                },
            )

        # Public target metadata remains available at inference, but it does
        # not create user/item embedding IDs.
        for record in self.valid_records + self.test_records:
            item_id = record["item"]
            self.item_info.setdefault(
                item_id,
                {
                    "item_name": record["item_name"],
                    "description": record["description"],
                    "category": record["category"],
                    "image_path": record["image_path"],
                },
            )

        self.num_users = len(self.user2id)
        self.num_items = len(self.item2id)
        self.num_categories = len(self.category2id)

    @staticmethod
    def _normalize_record(record: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        user_id = record.get("user_id") or record.get("user") or record.get("reviewerID")
        item_id = record.get("item") or record.get("parent_asin") or record.get("asin")
        if user_id is None or item_id is None:
            return None
        try:
            rating = float(record.get("rating", record.get("overall", 0.0)))
        except (TypeError, ValueError):
            return None
        review_text = _text(record.get("review_text") or record.get("text") or record.get("review"))
        if not review_text or not 1.0 <= rating <= 5.0:
            return None
        item_id = str(item_id).strip()
        template = record.get("template")
        template_feature = template[0] if isinstance(template, (list, tuple)) and len(template) > 0 else None
        template_explanation = template[2] if isinstance(template, (list, tuple)) and len(template) > 2 else None
        explanation_text = _text(
            template_explanation or record.get("explanation_text") or record.get("explanation") or review_text
        )
        category = _text(record.get("category")) or "Unknown"
        item_name = _text(record.get("item_name") or record.get("title")) or item_id
        official_feature = bool(record.get("official_feature", False))
        return {
            "user_id": str(user_id).strip(),
            "item": item_id,
            "rating": rating,
            "timestamp": normalize_timestamp(record.get("timestamp", record.get("unixReviewTime", 0))),
            "review_text": review_text,
            "explanation_text": explanation_text,
            "review_features": _features(
                template_feature or record.get("review_features"),
                "" if official_feature else explanation_text,
            ),
            "official_feature": official_feature,
            "item_name": item_name,
            "description": _text(record.get("description"))[:500],
            "category": category,
            "image_path": _text(record.get("image_path")),
            "source_index": int(record.get("source_index", -1)),
        }

    def _load_file(self, path: Optional[str], limit: Optional[int]) -> List[Dict[str, Any]]:
        if not path:
            return []
        records: List[Dict[str, Any]] = []
        with smart_open(path) as handle:
            for line in handle:
                try:
                    raw = json.loads(line)
                except (json.JSONDecodeError, TypeError):
                    continue
                record = self._normalize_record(raw)
                if record is not None:
                    records.append(record)
                if limit and len(records) >= limit:
                    break
        return records

    @staticmethod
    def _temporal_split(records: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
        groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for record in records:
            groups[record["user_id"]].append(record)
        train, valid, test = [], [], []
        for rows in groups.values():
            rows.sort(key=lambda row: (row["timestamp"], row["item"]))
            count = len(rows)
            if count < 3:
                train.extend(rows)
                continue
            valid_count = test_count = 1 if count < 15 else max(1, int(round(count * 0.1)))
            if valid_count + test_count >= count:
                valid_count = test_count = 1
            train_end = count - valid_count - test_count
            train.extend(rows[:train_end])
            valid.extend(rows[train_end:train_end + valid_count])
            test.extend(rows[train_end + valid_count:])
        return train, valid, test

    def frames(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        return pd.DataFrame(self.train_records), pd.DataFrame(self.valid_records), pd.DataFrame(self.test_records)


def compute_global_rating_mean(dataframe: pd.DataFrame) -> float:
    if dataframe.empty:
        raise ValueError("Cannot compute a global rating mean from an empty training set")
    return float(dataframe["rating"].mean())


class MyDataset(Dataset):
    """Build leakage-safe user profiles from interactions earlier than the target."""

    def __init__(
        self,
        dataframe: pd.DataFrame,
        data_manager: DashDataManager,
        global_mean: float,
        history_dataframe: pd.DataFrame,
        max_history_items: int = 20,
        profile_topk: int = 8,
        recent_items: int = 3,
        leave_one_out_history: bool = False,
    ):
        self.df = dataframe.reset_index(drop=True)
        self.dm = data_manager
        self.global_mean = float(global_mean)
        self.max_history_items = int(max_history_items)
        self.profile_topk = int(profile_topk)
        self.recent_items = int(recent_items)
        self.leave_one_out_history = bool(leave_one_out_history)
        self.history_by_user: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self.history_times: Dict[str, List[int]] = {}
        self._build_history_index(history_dataframe)

    def _build_history_index(self, history_dataframe: pd.DataFrame) -> None:
        for record in history_dataframe.to_dict("records"):
            entry = {
                "item": str(record["item"]),
                "item_name": _text(record.get("item_name")) or str(record["item"]),
                "description": _text(record.get("description")),
                "image_path": _text(record.get("image_path")),
                "category": _text(record.get("category")) or "Unknown",
                "cat_id": self.dm.category2id.get(_text(record.get("category")) or "Unknown", 0),
                "rating": float(record["rating"]),
                "timestamp": normalize_timestamp(record.get("timestamp", 0)),
                "review_text": _text(record.get("review_text")),
                "explanation_text": _text(record.get("explanation_text")) or _text(record.get("review_text")),
                "review_features": _features(
                    record.get("review_features"),
                    "" if bool(record.get("official_feature", False)) else _text(record.get("review_text")),
                ),
                "official_feature": bool(record.get("official_feature", False)),
                "source_index": int(record.get("source_index", -1)),
            }
            self.history_by_user[str(record["user_id"])].append(entry)
        for user_id, entries in self.history_by_user.items():
            entries.sort(key=lambda entry: (entry["timestamp"], entry["item"]))
            self.history_times[user_id] = [entry["timestamp"] for entry in entries]

    def __len__(self) -> int:
        return len(self.df)

    def _profile(self, history: Sequence[Dict[str, Any]], target_category: str) -> Tuple[str, str, str, str]:
        positive: Counter[str] = Counter()
        negative: Counter[str] = Counter()
        for entry in history:
            destination = positive if entry["rating"] >= 4.0 else negative if entry["rating"] <= 2.0 else None
            if destination is not None:
                # Same-category evidence is more useful for explaining this
                # target, while cross-category preferences remain available.
                weight = 2 if entry["category"] == target_category else 1
                for feature in entry["review_features"]:
                    destination[feature] += weight
        liked = ", ".join(feature for feature, _ in positive.most_common(self.profile_topk))
        disliked = ", ".join(feature for feature, _ in negative.most_common(self.profile_topk))
        recent = history[-self.recent_items:] if self.recent_items > 0 else []
        recent_text = "; ".join(
            f"{entry['item_name']} ({entry['category']}, rating {entry['rating']:.0f}/5)" for entry in recent
        )
        combined = ", ".join(filter(None, (liked, disliked)))
        return liked, disliked, recent_text, combined

    def __getitem__(self, index: int) -> Dict[str, Any]:
        row = self.df.iloc[index]
        user_id, item_id = str(row["user_id"]), str(row["item"])
        timestamp = normalize_timestamp(row.get("timestamp", 0))
        entries = self.history_by_user.get(user_id, [])
        times = self.history_times.get(user_id, [])
        if timestamp > 0 and any(value > 0 for value in times):
            history_end = bisect_left(times, timestamp)
            history = entries[max(0, history_end - self.max_history_items):history_end]
        else:
            # Sentires has no timestamps.  Validation/test may see all records
            # in the training fold; a training target sees all *other* train
            # records for that user.  This keeps personalization useful without
            # importing validation/test targets or the current explanation.
            source_index = int(row.get("source_index", -1))
            history = [
                entry for entry in entries
                if not (
                    self.leave_one_out_history
                    and source_index >= 0
                    and entry["source_index"] == source_index
                )
            ][-self.max_history_items:]
        month_seconds = 30.0 * 24 * 60 * 60
        time_gaps = [
            min(max((timestamp - entry["timestamp"]) / month_seconds, 0.0), 120.0)
            if timestamp > 0 and entry["timestamp"] > 0 else 0.0
            for entry in history
        ]
        target_category = _text(row.get("category")) or "Unknown"
        same_category_gaps = [
            gap for entry, gap in zip(history, time_gaps)
            if entry["category"] == target_category
        ]
        # Equation (6) uses an interval embedding, not an absolute calendar ID.
        target_interval = min(same_category_gaps) if same_category_gaps else (
            min(time_gaps) if time_gaps else 0.0
        )
        liked, disliked, recent_history, history_features = self._profile(history, target_category)

        image_path = _text(row.get("image_path"))
        return {
            "user": self.dm.user2id.get(user_id, 0),
            "item": self.dm.item2id.get(item_id, 0),
            "raw_user_id": user_id,
            "raw_item_id": item_id,
            "item_name": _text(row.get("item_name")) or item_id,
            "description": _text(row.get("description")),
            "category": target_category,
            "cat_id": self.dm.category2id.get(target_category, 0),
            "image_path": image_path,
            "image_available": float(bool(image_path and os.path.isfile(image_path))),
            "history_item_names": [entry["item_name"] for entry in history],
            "history_descriptions": [entry["description"] for entry in history],
            "history_image_paths": [entry["image_path"] for entry in history],
            "history_time_gaps": time_gaps,
            "history_category_ids": [entry["cat_id"] for entry in history],
            "target_interval": float(target_interval),
            "liked_aspects": liked,
            "disliked_aspects": disliked,
            "recent_history": recent_history,
            "history_features": history_features,
            "rating": float(row["rating"]),
            "review_text": _text(row.get("review_text")),
            "explanation_text": _text(row.get("explanation_text")) or _text(row.get("review_text")),
            "review_features": _features(
                row.get("review_features"),
                "" if bool(row.get("official_feature", False)) else (
                    _text(row.get("explanation_text")) or _text(row.get("review_text"))
                ),
            ),
        }


class CategoryAwareBatchSampler(Sampler[List[int]]):
    """Build deterministic mini-batches containing same-category pairs.

    The category contrastive objective needs at least two distinct items from
    one category. Ordinary random sampling, especially with batch size two,
    frequently produces no positive pair and therefore a zero contrastive
    loss. This sampler partitions every category into pairs and interleaves
    pairs from different categories. For an odd-sized category, one previously
    seen item from that category is repeated once so that the final item still
    has a distinct positive. Categories represented by only one training row
    are retained as fallback samples but cannot form a positive pair.

    Every epoch uses a seed-derived shuffle. Apart from at most one repeated
    partner per odd category, every training row occurs exactly once.
    """

    def __init__(
        self,
        dataset: MyDataset,
        batch_size: int,
        samples_per_category: int = 2,
        seed: int = 42,
        drop_last: bool = False,
    ) -> None:
        if batch_size < 2:
            raise ValueError("category-aware sampling requires batch_size >= 2")
        if samples_per_category < 2:
            raise ValueError("samples_per_category must be at least 2")
        if batch_size % samples_per_category != 0:
            raise ValueError(
                "batch_size must be divisible by samples_per_category for category-aware sampling"
            )
        self.dataset = dataset
        self.batch_size = int(batch_size)
        self.samples_per_category = int(samples_per_category)
        self.seed = int(seed)
        self.drop_last = bool(drop_last)
        self.epoch = 0
        self.groups: Dict[str, List[int]] = defaultdict(list)
        self.item_by_index = dataset.df["item"].astype(str).tolist()
        for index, category in enumerate(dataset.df["category"].astype(str).tolist()):
            self.groups[category].append(index)
        self._padded_size = sum(
            (
                math.ceil(len(indices) / self.samples_per_category)
                * self.samples_per_category
                if len(indices) >= 2
                else len(indices)
            )
            for indices in self.groups.values()
        )

    def __len__(self) -> int:
        if self.drop_last:
            return self._padded_size // self.batch_size
        return math.ceil(self._padded_size / self.batch_size)

    def __iter__(self) -> Iterator[List[int]]:
        rng = random.Random(self.seed + self.epoch)
        self.epoch += 1
        units_by_category: Dict[str, List[List[int]]] = {}
        fallback: List[int] = []
        for category, source_indices in self.groups.items():
            indices = list(source_indices)
            rng.shuffle(indices)
            if len(indices) < 2:
                fallback.extend(indices)
                continue
            units: List[List[int]] = []
            remaining = list(indices)
            while remaining:
                unit = [remaining.pop()]
                while remaining and len(unit) < self.samples_per_category:
                    used_items = {self.item_by_index[value] for value in unit}
                    different = next(
                        (
                            position
                            for position, value in enumerate(remaining)
                            if self.item_by_index[value] not in used_items
                        ),
                        len(remaining) - 1,
                    )
                    unit.append(remaining.pop(different))
                if len(unit) < self.samples_per_category:
                    used_items = {self.item_by_index[value] for value in unit}
                    candidates = [
                        value
                        for value in indices
                        if value not in unit and self.item_by_index[value] not in used_items
                    ] or [value for value in indices if value not in unit]
                    while len(unit) < self.samples_per_category:
                        unit.append(rng.choice(candidates))
                units.append(unit)
            rng.shuffle(units)
            units_by_category[category] = units

        # Round-robin categories so batch_size>=4 normally provides both
        # same-category positives and different-category negatives.
        ordered_units: List[List[int]] = []
        active = list(units_by_category)
        rng.shuffle(active)
        while active:
            next_active: List[str] = []
            for category in active:
                units = units_by_category[category]
                if units:
                    ordered_units.append(units.pop())
                if units:
                    next_active.append(category)
            rng.shuffle(next_active)
            active = next_active

        ordered: List[int] = [index for unit in ordered_units for index in unit]
        rng.shuffle(fallback)
        ordered.extend(fallback)
        for start in range(0, len(ordered), self.batch_size):
            batch = ordered[start:start + self.batch_size]
            if len(batch) < self.batch_size and self.drop_last:
                continue
            if len(batch) < self.batch_size and ordered:
                # Preserve a full micro-batch for stable gradient accumulation.
                refill = [value for value in ordered if value not in batch] or ordered
                while len(batch) < self.batch_size:
                    batch.append(rng.choice(refill))
            if batch:
                yield batch


class MyCollater:
    def __init__(
        self,
        clip_processor,
        tokenizer,
        max_history_items: int = 20,
        max_prompt_len: int = 160,
        max_target_len: int = 20,
        include_user_history: bool = True,
        include_user_identifier: bool = True,
        prompt_history_topk: int = 3,
        prompt_with_example: bool = True,
    ):
        self.clip_processor = clip_processor
        self.tokenizer = tokenizer
        self.max_history_items = int(max_history_items)
        self.max_prompt_len = int(max_prompt_len)
        self.max_target_len = int(max_target_len)
        self.include_user_history = bool(include_user_history)
        self.include_user_identifier = bool(include_user_identifier)
        self.prompt_history_topk = max(0, int(prompt_history_topk))
        self.prompt_with_example = bool(prompt_with_example)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

    def build_prompt(self, sample: Dict[str, Any]) -> str:
        user_identifier = f"U_{sample['user']}" if self.include_user_identifier else "Hidden for ablation"
        if self.include_user_history:
            # Prompt-visible preferences are extracted only from the user's
            # leakage-safe training history.  The current target feature,
            # rating and explanation are never inserted into the prompt.
            aspects = [
                part.strip()
                for part in sample["liked_aspects"].split(",")
                if part.strip()
            ]
            aspects = aspects[:self.prompt_history_topk]
            user_preferences = ", ".join(aspects) or "none available"
        else:
            user_preferences = "Hidden for ablation"
        demonstration = (
            "Example Input: Based on the user's historical preferences "
            "[comfortable, durable, lightweight], the target item's categories "
            "[Sports & Outdoors], and its multimodal characteristics, explain why "
            "[Trail Shoes] matches the preferences of user [U_example].\n"
            "Example Output: Explanation: These lightweight trail shoes offer the "
            "comfortable and durable design the user prefers.\n\n"
            if self.prompt_with_example else ""
        )
        return (
            "Instruction: Please generate a concise personalized recommendation explanation.\n\n"
            f"{demonstration}"
            "Input: Based on the user’s historical preferences "
            f"[{user_preferences}], the target item’s categories "
            f"[{sample['category']}], and its multimodal characteristics, "
            f"explain why [{sample['item_name']}] matches the preferences "
            f"of user [{user_identifier}].\n\n"
            "Output: Explanation:"
        )

    def build_target(self, review: str) -> str:
        """Return exactly the reference visible under the 20-BPE protocol."""
        token_ids = self.tokenizer(
            _text(review), add_special_tokens=False, truncation=True, max_length=self.max_target_len
        ).input_ids
        return self.tokenizer.decode(token_ids, skip_special_tokens=True).strip()

    @staticmethod
    def load_image(path: str) -> Image.Image:
        try:
            with Image.open(path) as image:
                return image.convert("RGB")
        except Exception:
            return Image.new("RGB", (224, 224), color="white")

    def encode_history_items(
        self,
        batch_names: Sequence[Sequence[str]],
        batch_descriptions: Sequence[Sequence[str]],
        batch_image_paths: Sequence[Sequence[str]],
        batch_gaps: Sequence[Sequence[float]],
        batch_categories: Sequence[Sequence[int]],
    ):
        flat_texts, flat_images, flat_image_masks = [], [], []
        padded_gaps, padded_categories, item_masks = [], [], []
        for names, descriptions, image_paths, gaps, categories in zip(
            batch_names,
            batch_descriptions,
            batch_image_paths,
            batch_gaps,
            batch_categories,
        ):
            names = list(names[-self.max_history_items:])
            descriptions = list(descriptions[-self.max_history_items:])
            image_paths = list(image_paths[-self.max_history_items:])
            gaps = list(gaps[-self.max_history_items:])
            categories = list(categories[-self.max_history_items:])
            valid = len(names)
            padding = self.max_history_items - valid
            for name, description, image_path in zip(names, descriptions, image_paths):
                flat_texts.append(
                    f"Title: {name}. Description: {description[:240]}"
                )
                flat_images.append(self.load_image(image_path))
                flat_image_masks.append(float(bool(image_path and os.path.isfile(image_path))))
            flat_texts.extend(["Unknown item"] * padding)
            flat_images.extend([Image.new("RGB", (224, 224), color="white") for _ in range(padding)])
            flat_image_masks.extend([0.0] * padding)
            padded_gaps.append(gaps + [0.0] * padding)
            padded_categories.append(categories + [0] * padding)
            item_masks.append([1.0] * valid + [0.0] * padding)
        encoded = self.clip_processor(
            text=flat_texts,
            images=flat_images,
            padding="max_length",
            truncation=True,
            max_length=77,
            return_tensors="pt",
        )
        batch_size = len(batch_names)
        return (
            encoded.input_ids.view(batch_size, self.max_history_items, -1),
            encoded.attention_mask.view(batch_size, self.max_history_items, -1),
            encoded.pixel_values.view(batch_size, self.max_history_items, *encoded.pixel_values.shape[1:]),
            torch.tensor(flat_image_masks, dtype=torch.float).view(batch_size, self.max_history_items),
            torch.tensor(padded_gaps, dtype=torch.float),
            torch.tensor(item_masks, dtype=torch.float),
            torch.tensor(padded_categories, dtype=torch.long),
        )

    def encode_training(self, prompts: Sequence[str], targets: Sequence[str]):
        # max_target_len counts explanation BPE tokens. EOS is an additional
        # control token and is not part of the reported explanation length.
        maximum_length = self.max_prompt_len + self.max_target_len + 1
        encoded_rows = []
        for prompt, target in zip(prompts, targets):
            prompt_ids = self.tokenizer(
                prompt, add_special_tokens=True, truncation=True, max_length=self.max_prompt_len
            ).input_ids
            target_ids = self.tokenizer(
                target, add_special_tokens=False, truncation=True, max_length=self.max_target_len
            ).input_ids
            if self.tokenizer.eos_token_id is not None:
                target_ids = target_ids + [self.tokenizer.eos_token_id]
            input_ids = (prompt_ids + target_ids)[:maximum_length]
            labels = ([-100] * len(prompt_ids) + target_ids)[:maximum_length]
            encoded_rows.append((input_ids, labels))

        # Dynamic padding is mathematically equivalent to fixed padding but
        # avoids sending hundreds of padding positions through the 7B model.
        batch_length = max(len(input_ids) for input_ids, _ in encoded_rows)
        input_rows, mask_rows, label_rows = [], [], []
        for input_ids, labels in encoded_rows:
            attention_mask = [1] * len(input_ids)
            padding = batch_length - len(input_ids)
            input_rows.append(torch.tensor(input_ids + [self.tokenizer.pad_token_id] * padding, dtype=torch.long))
            mask_rows.append(torch.tensor(attention_mask + [0] * padding, dtype=torch.long))
            label_rows.append(torch.tensor(labels + [-100] * padding, dtype=torch.long))
        return torch.stack(input_rows), torch.stack(mask_rows), torch.stack(label_rows)

    def __call__(self, batch: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
        prompts = [self.build_prompt(sample) for sample in batch]
        targets = [self.build_target(sample["explanation_text"]) for sample in batch]
        clip_texts = [
            f"Title: {sample['item_name']}. Category: {sample['category']}. "
            f"Description: {sample['description'][:240]}"
            for sample in batch
        ]
        images = [self.load_image(sample["image_path"]) for sample in batch]
        clip_inputs = self.clip_processor(
            text=clip_texts,
            images=images,
            padding="max_length",
            truncation=True,
            max_length=77,
            return_tensors="pt",
        )
        (
            history_clip_input_ids,
            history_clip_attention_mask,
            history_pixel_values,
            history_image_mask,
            history_time_gaps,
            history_item_mask,
            history_category_ids,
        ) = self.encode_history_items(
            [sample["history_item_names"] for sample in batch],
            [sample["history_descriptions"] for sample in batch],
            [sample["history_image_paths"] for sample in batch],
            [sample["history_time_gaps"] for sample in batch],
            [sample["history_category_ids"] for sample in batch],
        )
        train_input_ids, train_attention_mask, labels = self.encode_training(prompts, targets)
        previous_padding_side = self.tokenizer.padding_side
        self.tokenizer.padding_side = "left"
        generation_inputs = self.tokenizer(
            prompts,
            padding=True,
            truncation=True,
            max_length=self.max_prompt_len,
            return_tensors="pt",
        )
        self.tokenizer.padding_side = previous_padding_side
        return {
            "clip_input_ids": clip_inputs.input_ids,
            "clip_attention_mask": clip_inputs.attention_mask,
            "pixel_values": clip_inputs.pixel_values,
            "image_mask": torch.tensor([sample["image_available"] for sample in batch], dtype=torch.float),
            "history_clip_input_ids": history_clip_input_ids,
            "history_clip_attention_mask": history_clip_attention_mask,
            "history_pixel_values": history_pixel_values,
            "history_image_mask": history_image_mask,
            "history_time_gaps": history_time_gaps,
            "history_item_mask": history_item_mask,
            "history_category_ids": history_category_ids,
            "cat_ids": torch.tensor([sample["cat_id"] for sample in batch], dtype=torch.long),
            "target_interval": torch.tensor([sample["target_interval"] for sample in batch], dtype=torch.float),
            "users": torch.tensor([sample["user"] for sample in batch], dtype=torch.long),
            "items": torch.tensor([sample["item"] for sample in batch], dtype=torch.long),
            "ratings": torch.tensor([sample["rating"] for sample in batch], dtype=torch.float),
            "train_input_ids": train_input_ids,
            "train_attention_mask": train_attention_mask,
            "labels": labels,
            "llm_input_ids": generation_inputs.input_ids,
            "llm_attention_mask": generation_inputs.attention_mask,
            # Evaluation must use the same 20-BPE reference used for training.
            "references": targets,
            "reference_features": [sample["review_features"] for sample in batch],
            "history_features": [sample["history_features"] for sample in batch],
            "liked_aspects": [sample["liked_aspects"] for sample in batch],
            "disliked_aspects": [sample["disliked_aspects"] for sample in batch],
            "raw_user_ids": [sample["raw_user_id"] for sample in batch],
            "raw_item_ids": [sample["raw_item_id"] for sample in batch],
            "item_names": [sample["item_name"] for sample in batch],
            "categories": [sample["category"] for sample in batch],
        }
