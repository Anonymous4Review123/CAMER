"""CAMER implementation aligned with Equations (1)--(12) of the paper.

The implementation deliberately keeps the paper variables visible:
``item_text/item_visual`` are modality-specific item representations,
``user_category`` is z_u^c, and the continuous prefix is built only from
``[z_u^c, z_i, e_i^c]``.  Historical target labels/reviews are never used as
target-side inputs.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import CLIPModel


class FeatureProjector(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, output_dim),
            nn.LayerNorm(output_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ContinuousPrefixProjector(nn.Module):
    """Project p_ui=[z_u^c,z_i,e_i^c] to continuous LLM prefix tokens."""

    def __init__(self, feat_dim: int, llm_hidden: int, prefix_len: int):
        super().__init__()
        self.prefix_len = int(prefix_len)
        self.llm_hidden = int(llm_hidden)
        self.net = nn.Sequential(
            nn.Linear(feat_dim * 3, feat_dim * 2),
            nn.LayerNorm(feat_dim * 2),
            nn.GELU(),
            nn.Linear(feat_dim * 2, prefix_len * llm_hidden),
        )

    def forward(self, prefix_source: torch.Tensor) -> torch.Tensor:
        values = self.net(prefix_source)
        return values.view(values.size(0), self.prefix_len, self.llm_hidden)


class CategoryGuidedMultimodalAlignment(nn.Module):
    """Equation (1): exact category-guided cross-modal attention."""

    def __init__(self, dimension: int):
        super().__init__()
        self.query = nn.Linear(dimension, dimension, bias=False)
        self.key = nn.Linear(dimension, dimension, bias=False)
        self.value = nn.Linear(dimension, dimension, bias=False)
        self.scale = dimension ** -0.5
        # Shared W0 in Equation (2); CLIP text length is fixed to 77.
        self.pool_weight = nn.Parameter(torch.zeros(77))

    @staticmethod
    def _masked_pool(tokens: torch.Tensor, scores: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        scores = scores.masked_fill(~mask.bool(), torch.finfo(scores.dtype).min)
        weights = torch.softmax(scores, dim=1)
        weights = torch.where(mask.bool(), weights, torch.zeros_like(weights))
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        return torch.sum(tokens * weights.unsqueeze(-1), dim=1)

    def forward(
        self,
        text_tokens: torch.Tensor,
        visual_tokens: torch.Tensor,
        category: torch.Tensor,
        text_mask: torch.Tensor,
        visual_available: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        query = text_tokens + category.unsqueeze(1)
        projected_query = self.query(query)

        text_scores = torch.matmul(
            projected_query, self.key(text_tokens).transpose(-1, -2)
        ) * self.scale
        text_scores = text_scores.masked_fill(
            ~text_mask.bool().unsqueeze(1), torch.finfo(text_scores.dtype).min
        )
        text_attention = torch.softmax(text_scores, dim=-1)
        aligned_text = torch.matmul(text_attention, self.value(text_tokens))

        visual_scores = torch.matmul(
            projected_query, self.key(visual_tokens).transpose(-1, -2)
        ) * self.scale
        visual_attention = torch.softmax(visual_scores, dim=-1)
        aligned_visual_tokens = torch.matmul(
            visual_attention, self.value(visual_tokens)
        )

        text_vector = self._masked_pool(
            aligned_text,
            self.pool_weight[: aligned_text.size(1)].unsqueeze(0).expand(aligned_text.size(0), -1),
            text_mask,
        )
        visual_mask = text_mask.bool() & visual_available.bool().unsqueeze(1)
        visual_vector = self._masked_pool(
            aligned_visual_tokens,
            self.pool_weight[: aligned_visual_tokens.size(1)].unsqueeze(0).expand(aligned_visual_tokens.size(0), -1),
            visual_mask,
        )
        visual_vector = visual_vector * visual_available.to(visual_vector.dtype).unsqueeze(-1)
        return text_vector, visual_vector


class LayerwiseModalityFusion(nn.Module):
    """Equation (7): exact layerwise category-conditioned modality fusion."""

    def __init__(self, dimension: int, layers: int = 2):
        super().__init__()
        self.query = nn.ModuleList([nn.Linear(dimension, dimension, bias=False) for _ in range(layers)])
        self.key = nn.ModuleList([nn.Linear(dimension, dimension, bias=False) for _ in range(layers)])
        self.value = nn.ModuleList([nn.Linear(dimension, dimension, bias=False) for _ in range(layers)])
        self.scale = dimension ** -0.5

    def forward(
        self,
        text_vector: torch.Tensor,
        visual_vector: torch.Tensor,
        category: torch.Tensor,
        visual_available: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        modalities = torch.stack([text_vector, visual_vector], dim=1)
        state = torch.zeros_like(category)
        last_weights = torch.zeros(
            modalities.size(0), 2, device=modalities.device, dtype=modalities.dtype
        )
        for layer_index, (query, key, value) in enumerate(
            zip(self.query, self.key, self.value)
        ):
            d_i = category if layer_index == 0 else state + category
            layer_query = query(d_i).unsqueeze(1)
            scores = (layer_query * key(modalities)).sum(dim=-1) * self.scale
            modality_available = torch.stack(
                [torch.ones_like(visual_available, dtype=torch.bool), visual_available.bool()], dim=1
            )
            scores = scores.masked_fill(~modality_available, torch.finfo(scores.dtype).min)
            last_weights = torch.softmax(scores, dim=1)
            state = torch.sum(last_weights.unsqueeze(-1) * value(modalities), dim=1)
        return state, last_weights


class CategoryAwareUserPreference(nn.Module):
    """Equations (2)--(5): category drift and user modality preference."""

    def __init__(self, dimension: int, disable_modality_preference: bool = False, disable_category_drift: bool = False):
        super().__init__()
        self.disable_modality_preference = bool(disable_modality_preference)
        self.disable_category_drift = bool(disable_category_drift)
        self.decay = nn.Linear(dimension, 1)  # Equation (3)
        self.modality_attention = nn.Linear(dimension, dimension, bias=False)  # W2

    def forward(
        self,
        history_text: torch.Tensor,
        history_visual: torch.Tensor,
        target_category: torch.Tensor,
        history_category_ids: torch.Tensor,
        target_category_ids: torch.Tensor,
        time_gaps: torch.Tensor,
        item_mask: torch.Tensor,
        history_image_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        same_category = history_category_ids.eq(target_category_ids.unsqueeze(1))
        category_mask = (
            item_mask.bool() if self.disable_category_drift
            else same_category & item_mask.bool()
        )

        # lambda_c is learned from the target category rather than globally fixed.
        decay_rate = (
            torch.ones(target_category.size(0), 1, device=target_category.device, dtype=target_category.dtype)
            if self.disable_category_drift
            else torch.sigmoid(self.decay(target_category)).clamp_min(1e-4)
        )
        decay_weights = torch.exp(-decay_rate * time_gaps.float()) * category_mask.float()
        text_weights = decay_weights / decay_weights.sum(dim=1, keepdim=True).clamp_min(1e-8)

        visual_weights = decay_weights * history_image_mask.float()
        visual_weights = visual_weights / visual_weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        user_text = torch.sum(history_text * text_weights.unsqueeze(-1), dim=1)
        user_visual = torch.sum(history_visual * visual_weights.unsqueeze(-1), dim=1)

        has_text = category_mask.any(dim=1)
        has_visual = (category_mask & history_image_mask.bool()).any(dim=1)
        modality_states = torch.stack([user_text, user_visual], dim=1)
        projected_category = self.modality_attention(target_category).unsqueeze(1)
        modality_scores = (modality_states * projected_category).sum(dim=-1)
        availability = torch.stack([has_text, has_visual], dim=1)
        modality_scores = modality_scores.masked_fill(
            ~availability, torch.finfo(modality_scores.dtype).min
        )
        # Cold target categories receive a zero preference instead of NaNs.
        cold = ~availability.any(dim=1)
        modality_scores = torch.where(cold.unsqueeze(1), torch.zeros_like(modality_scores), modality_scores)
        beta = torch.softmax(modality_scores, dim=1)
        if self.disable_modality_preference:
            beta = availability.float()
            beta = beta / beta.sum(dim=1, keepdim=True).clamp_min(1.0)
        beta = torch.where(cold.unsqueeze(1), torch.zeros_like(beta), beta)
        user_category = torch.sum(beta.unsqueeze(-1) * modality_states, dim=1)
        user_category = torch.where(cold.unsqueeze(-1), torch.zeros_like(user_category), user_category)
        return user_category, beta, decay_rate.squeeze(-1)


class MyModel(nn.Module):
    def __init__(
        self,
        llm_hidden: int,
        feat_dim: int = 512,
        num_categories: int = 20,
        num_users: int = 1,
        num_items: int = 1,
        global_rating_mean: float = 4.2,
        clip_path: str = "openai/clip-vit-base-patch32",
        prefix_len: int = 16,
        freeze_clip: bool = True,
        modality_layers: int = 2,
        contrastive_temperature: float = 0.07,
        cache_clip_features: bool = True,
        no_cmfa: bool = False,
        no_cmpm: bool = False,
        no_cidm: bool = False,
    ):
        super().__init__()
        self.feat_dim = int(feat_dim)
        self.global_rating_mean = float(global_rating_mean)
        self.freeze_clip = bool(freeze_clip)
        self.contrastive_temperature = float(contrastive_temperature)
        self.cache_clip_features = bool(cache_clip_features and freeze_clip)
        self.no_cmfa = bool(no_cmfa)
        self._clip_cache: Dict[int, Tuple[torch.Tensor, torch.Tensor]] = {}

        clip = CLIPModel.from_pretrained(clip_path, local_files_only=True)
        self.text_encoder = clip.text_model
        self.image_encoder = clip.vision_model
        if freeze_clip:
            for parameter in self.text_encoder.parameters():
                parameter.requires_grad = False
            for parameter in self.image_encoder.parameters():
                parameter.requires_grad = False

        self.text_projection = nn.Linear(512, feat_dim)
        self.image_projection = nn.Linear(768, feat_dim)
        # The paper defines category c as a trainable vector.
        self.category_embedding = nn.Embedding(num_categories, feat_dim, padding_idx=0)
        self.alignment = CategoryGuidedMultimodalAlignment(feat_dim)
        self.item_fusion = LayerwiseModalityFusion(feat_dim, modality_layers)
        self.user_preference = CategoryAwareUserPreference(
            feat_dim,
            disable_modality_preference=no_cmpm,
            disable_category_drift=no_cidm,
        )
        self.time_projection = FeatureProjector(1, feat_dim)

        self.user_bias = nn.Embedding(num_users, 1, padding_idx=0)
        self.item_bias = nn.Embedding(num_items, 1, padding_idx=0)
        nn.init.zeros_(self.user_bias.weight)
        nn.init.zeros_(self.item_bias.weight)
        self.rating_head = nn.Sequential(
            nn.Linear(feat_dim * 4, feat_dim),
            nn.GELU(),
            nn.Linear(feat_dim, 1),
        )
        nn.init.zeros_(self.rating_head[-1].weight)
        nn.init.zeros_(self.rating_head[-1].bias)
        self.prefix_projection = ContinuousPrefixProjector(feat_dim, llm_hidden, prefix_len)
        self.model = None
        self.tokenizer = None

    def train(self, mode: bool = True):
        super().train(mode)
        if self.freeze_clip:
            self.text_encoder.eval()
            self.image_encoder.eval()
        return self

    def category_vector(self, category_ids: torch.Tensor) -> torch.Tensor:
        ids = category_ids.long().clamp(0, self.category_embedding.num_embeddings - 1)
        return self.category_embedding(ids)

    def _clip_hidden(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        pixel_values: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # Keeping one batched path makes target and historical item semantics identical.
        text = self.text_encoder(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        visual = self.image_encoder(pixel_values=pixel_values).last_hidden_state
        return text, visual

    def encode_item_modalities(
        self,
        clip_input_ids: torch.Tensor,
        clip_attention_mask: torch.Tensor,
        pixel_values: torch.Tensor,
        category_ids: torch.Tensor,
        image_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        text_hidden, visual_hidden = self._clip_hidden(
            clip_input_ids, clip_attention_mask, pixel_values
        )
        text_tokens = self.text_projection(text_hidden)
        visual_tokens = self.image_projection(visual_hidden)
        category = self.category_vector(category_ids)
        if self.no_cmfa:
            text_mask = clip_attention_mask.to(text_tokens.dtype).unsqueeze(-1)
            text_vector = (text_tokens * text_mask).sum(dim=1) / text_mask.sum(dim=1).clamp_min(1.0)
            visual_vector = visual_tokens.mean(dim=1) * image_mask.to(visual_tokens.dtype).unsqueeze(-1)
        else:
            text_vector, visual_vector = self.alignment(
                text_tokens, visual_tokens, category, clip_attention_mask.bool(), image_mask
            )
        item_vector, modality_weights = self.item_fusion(
            text_vector, visual_vector, category, image_mask
        )
        return text_vector, visual_vector, item_vector, modality_weights

    def build_representations(
        self,
        item_vector: torch.Tensor,
        history_text: torch.Tensor,
        history_visual: torch.Tensor,
        history_category_ids: torch.Tensor,
        history_time_gaps: torch.Tensor,
        history_item_mask: torch.Tensor,
        history_image_mask: torch.Tensor,
        target_category_ids: torch.Tensor,
        target_interval: torch.Tensor,
    ):
        category = self.category_vector(target_category_ids)
        user_category, modality_beta, decay_rate = self.user_preference(
            history_text,
            history_visual,
            category,
            history_category_ids,
            target_category_ids,
            history_time_gaps,
            history_item_mask,
            history_image_mask,
        )
        # Equation (8): no ID embeddings, absolute time, or rating prior in p_ui.
        prefix_source = torch.cat([user_category, item_vector, category], dim=-1)
        time_vector = self.time_projection(torch.log1p(target_interval.float()).unsqueeze(-1))
        rating_context = torch.cat([user_category, item_vector, category, time_vector], dim=-1)
        return prefix_source, rating_context, user_category, modality_beta, decay_rate

    def predict_rating(
        self,
        rating_context: torch.Tensor,
        users: torch.Tensor,
        items: torch.Tensor,
        clamp_output: bool = False,
    ) -> torch.Tensor:
        users = users.long().clamp(0, self.user_bias.num_embeddings - 1)
        items = items.long().clamp(0, self.item_bias.num_embeddings - 1)
        prediction = (
            self.global_rating_mean
            + self.user_bias(users).squeeze(-1)
            + self.item_bias(items).squeeze(-1)
            + self.rating_head(rating_context).squeeze(-1)
        )
        return prediction.clamp(1.0, 5.0) if clamp_output else prediction

    def category_contrastive_loss(
        self,
        item_vectors: torch.Tensor,
        category_ids: torch.Tensor,
        valid_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Equation (11): category-aware positive/negative item contrast.

        The numerator uses a same-category item and the denominator contains
        only different-category items, exactly as printed in Equation (11).
        """
        vectors = F.normalize(item_vectors[valid_mask.bool()].float(), dim=-1)
        labels = category_ids[valid_mask.bool()].long()
        if vectors.size(0) < 2:
            return item_vectors.sum() * 0.0
        logits = vectors @ vectors.t() / max(self.contrastive_temperature, 1e-6)
        eye = torch.eye(vectors.size(0), device=vectors.device, dtype=torch.bool)
        positives = labels.unsqueeze(0).eq(labels.unsqueeze(1)) & ~eye & labels.unsqueeze(0).ne(0)
        negatives = labels.unsqueeze(0).ne(labels.unsqueeze(1)) & ~eye & labels.unsqueeze(0).ne(0)
        valid_anchor = positives.any(dim=1) & negatives.any(dim=1)
        if not bool(valid_anchor.any()):
            return item_vectors.sum() * 0.0
        losses = []
        for anchor in torch.where(valid_anchor)[0]:
            positive_logits = logits[anchor][positives[anchor]]
            negative_logits = logits[anchor][negatives[anchor]]
            for positive_logit in positive_logits:
                denominator = torch.logsumexp(negative_logits, dim=0)
                losses.append(denominator - positive_logit)
        if not losses:
            return item_vectors.sum() * 0.0
        return torch.stack(losses).mean()

    def get_prefix(self, prefix_source: torch.Tensor) -> torch.Tensor:
        return self.prefix_projection(prefix_source)

    def forward(
        self,
        clip_input_ids: torch.Tensor,
        clip_attention_mask: torch.Tensor,
        pixel_values: torch.Tensor,
        image_mask: torch.Tensor,
        cat_ids: torch.Tensor,
        history_clip_input_ids: torch.Tensor,
        history_clip_attention_mask: torch.Tensor,
        history_pixel_values: torch.Tensor,
        history_image_mask: torch.Tensor,
        history_time_gaps: torch.Tensor,
        history_item_mask: torch.Tensor,
        history_category_ids: torch.Tensor,
        target_interval: torch.Tensor,
        users: torch.Tensor,
        items: torch.Tensor,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
    ):
        _, _, item_vector, item_beta = self.encode_item_modalities(
            clip_input_ids, clip_attention_mask, pixel_values, cat_ids, image_mask
        )

        batch, history = history_category_ids.shape
        flat_shape = batch * history
        history_text, history_visual, history_items, _ = self.encode_item_modalities(
            history_clip_input_ids.view(flat_shape, -1),
            history_clip_attention_mask.view(flat_shape, -1),
            history_pixel_values.view(flat_shape, *history_pixel_values.shape[2:]),
            history_category_ids.view(-1),
            history_image_mask.view(-1),
        )
        history_text = history_text.view(batch, history, -1)
        history_visual = history_visual.view(batch, history, -1)
        history_items = history_items.view(batch, history, -1)

        prefix_source, rating_context, user_category, user_beta, decay_rate = self.build_representations(
            item_vector,
            history_text,
            history_visual,
            history_category_ids,
            history_time_gaps,
            history_item_mask,
            history_image_mask,
            cat_ids,
            target_interval,
        )
        rating_prediction = self.predict_rating(rating_context, users, items, clamp_output=False)
        contrast_items = torch.cat([item_vector.unsqueeze(1), history_items], dim=1)
        contrast_categories = torch.cat([cat_ids.unsqueeze(1), history_category_ids], dim=1)
        contrast_mask = torch.cat(
            [torch.ones(batch, 1, device=item_vector.device), history_item_mask], dim=1
        ).bool()
        contrastive_loss = self.category_contrastive_loss(
            contrast_items.reshape(-1, contrast_items.size(-1)),
            contrast_categories.reshape(-1),
            contrast_mask.reshape(-1),
        )

        language_output = None
        prefix = self.get_prefix(prefix_source)
        if input_ids is not None:
            token_embeddings = self.model.get_input_embeddings()(input_ids)
            prefix = prefix.to(token_embeddings.dtype)
            inputs_embeds = torch.cat([prefix, token_embeddings], dim=1)
            prefix_mask = torch.ones(
                prefix.size(0), prefix.size(1), device=attention_mask.device, dtype=attention_mask.dtype
            )
            full_mask = torch.cat([prefix_mask, attention_mask], dim=1)
            if labels is not None:
                prefix_labels = torch.full(
                    (labels.size(0), prefix.size(1)), -100, device=labels.device, dtype=torch.long
                )
                labels = torch.cat([prefix_labels, labels], dim=1)
            language_output = self.model(
                inputs_embeds=inputs_embeds, attention_mask=full_mask, labels=labels
            )
        diagnostics = {
            "user_modality_weights": user_beta,
            "item_modality_weights": item_beta,
            "category_decay_rate": decay_rate,
        }
        return language_output, prefix_source, rating_context, rating_prediction, contrastive_loss, diagnostics

    @torch.no_grad()
    def generate_with_prefix(
        self,
        prefix_source: torch.Tensor,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        max_new_tokens: int = 20,
        min_new_tokens: int = 6,
        decoding_strategy: str = "beam",
        num_beams: int = 4,
        temperature: float = 0.8,
        top_p: float = 0.9,
        top_k: int = 50,
        penalty_alpha: float = 0.6,
        contrastive_top_k: int = 4,
        length_penalty: float = 1.0,
        repetition_penalty: float = 1.05,
        no_repeat_ngram_size: int = 3,
    ) -> torch.Tensor:
        token_embeddings = self.model.get_input_embeddings()(input_ids)
        prefix = self.get_prefix(prefix_source).to(token_embeddings.dtype)
        inputs_embeds = torch.cat([prefix, token_embeddings], dim=1)
        prefix_mask = torch.ones(
            prefix.size(0), prefix.size(1), device=attention_mask.device, dtype=attention_mask.dtype
        )
        kwargs = dict(
            inputs_embeds=inputs_embeds,
            attention_mask=torch.cat([prefix_mask, attention_mask], dim=1),
            max_new_tokens=max_new_tokens,
            min_new_tokens=min_new_tokens,
            repetition_penalty=repetition_penalty,
            no_repeat_ngram_size=no_repeat_ngram_size,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
            bos_token_id=self.tokenizer.bos_token_id,
        )
        if decoding_strategy == "greedy":
            kwargs.update(do_sample=False, num_beams=1)
        elif decoding_strategy == "beam":
            kwargs.update(do_sample=False, num_beams=max(2, num_beams), length_penalty=length_penalty)
        elif decoding_strategy == "sample":
            kwargs.update(do_sample=True, temperature=temperature, top_p=top_p, top_k=top_k)
        elif decoding_strategy == "diverse_beam":
            beams = max(4, num_beams)
            kwargs.update(do_sample=False, num_beams=beams, num_beam_groups=2, diversity_penalty=0.3)
        elif decoding_strategy == "contrastive":
            kwargs.update(do_sample=False, penalty_alpha=penalty_alpha, top_k=max(2, contrastive_top_k))
        else:
            raise ValueError(f"unsupported decoding strategy: {decoding_strategy}")
        return self.model.generate(**kwargs)
