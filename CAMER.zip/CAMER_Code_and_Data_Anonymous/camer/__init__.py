"""CAMER: Category-Aware Multimodal Explainable Recommendation."""

__version__ = "0.1.0"
