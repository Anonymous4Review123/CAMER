"""Train personalized multimodal explanation generation on fixed clean splits."""

from __future__ import annotations

import json
import math
import os
import random
from argparse import ArgumentParser, Namespace
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from peft import LoraConfig, TaskType, get_peft_model
from torch.optim import AdamW
from torch.utils.data import DataLoader, Subset
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer, CLIPProcessor, get_linear_schedule_with_warmup

from camer.dataset.dataloader import (
    CategoryAwareBatchSampler,
    DashDataManager,
    MyCollater,
    MyDataset,
    compute_global_rating_mean,
)
from camer.eval.gen_eval import generate_and_eval
from camer.model.model import MyModel


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def move_batch(batch: Dict[str, Any], device: torch.device) -> Dict[str, Any]:
    return {key: value.to(device) if torch.is_tensor(value) else value for key, value in batch.items()}


def init_llm(args: Namespace, device: torch.device):
    tokenizer = AutoTokenizer.from_pretrained(args.model_name, use_fast=False, local_files_only=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    dtype = torch.float16 if device.type == "cuda" else torch.float32
    base_model = AutoModelForCausalLM.from_pretrained(
        args.model_name,
        dtype=dtype,
        trust_remote_code=True,
        local_files_only=True,
        low_cpu_mem_usage=True,
    )
    base_model.config.pad_token_id = tokenizer.pad_token_id
    base_model.config.use_cache = False
    lora_config = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        bias="none",
        task_type=TaskType.CAUSAL_LM,
    )
    model = get_peft_model(base_model, lora_config)
    model.print_trainable_parameters()
    return tokenizer, model


def build_optimizer(model: MyModel, args: Namespace) -> AdamW:
    lora_parameters, rating_parameters, representation_parameters = [], [], []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if "lora_" in name:
            lora_parameters.append(parameter)
        elif any(key in name for key in ("rating_head", "user_bias", "item_bias")):
            rating_parameters.append(parameter)
        else:
            representation_parameters.append(parameter)
    groups = []
    if lora_parameters:
        groups.append({"params": lora_parameters, "lr": args.lora_lr})
    if representation_parameters:
        groups.append({"params": representation_parameters, "lr": args.prefix_lr})
    if rating_parameters:
        groups.append({"params": rating_parameters, "lr": args.rating_lr})
    if not groups:
        raise RuntimeError("No trainable parameters were found")
    # Equation (12) adds eta * ||Theta||_2^2 explicitly to the objective.
    # AdamW's decoupled weight decay is therefore disabled.
    return AdamW(groups, weight_decay=0.0)


def trainable_l2_penalty(model: MyModel) -> torch.Tensor:
    """Return ||Theta||_2^2 over the parameters updated by this training run."""
    penalty = None
    for parameter in model.parameters():
        if not parameter.requires_grad:
            continue
        value = parameter.float().pow(2).sum()
        penalty = value if penalty is None else penalty + value
    if penalty is None:
        raise RuntimeError("No trainable parameters were found for L2 regularization")
    return penalty


def forward_batch(model: MyModel, batch: Dict[str, Any], with_language: bool = True):
    language_inputs = (
        {
            "input_ids": batch["train_input_ids"],
            "attention_mask": batch["train_attention_mask"],
            "labels": batch["labels"],
        }
        if with_language
        else {}
    )
    return model(
        clip_input_ids=batch["clip_input_ids"],
        clip_attention_mask=batch["clip_attention_mask"],
        pixel_values=batch["pixel_values"],
        image_mask=batch["image_mask"],
        cat_ids=batch["cat_ids"],
        history_clip_input_ids=batch["history_clip_input_ids"],
        history_clip_attention_mask=batch["history_clip_attention_mask"],
        history_pixel_values=batch["history_pixel_values"],
        history_image_mask=batch["history_image_mask"],
        history_time_gaps=batch["history_time_gaps"],
        history_item_mask=batch["history_item_mask"],
        history_category_ids=batch["history_category_ids"],
        target_interval=batch["target_interval"],
        users=batch["users"],
        items=batch["items"],
        **language_inputs,
    )


def train_one_epoch(model, loader, optimizer, scheduler, scaler, device, args) -> Dict[str, float]:
    model.train()
    optimizer.zero_grad(set_to_none=True)
    total, total_gen, total_rating, total_contrastive, total_l2 = 0.0, 0.0, 0.0, 0.0, 0.0
    for step, batch in enumerate(tqdm(loader, desc="Train"), start=1):
        batch = move_batch(batch, device)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"):
            language_output, _, _, rating_prediction, contrastive_loss, _ = forward_batch(
                model, batch, with_language=True
            )
            generation_loss = language_output.loss
            rating_loss = F.mse_loss(rating_prediction.float(), batch["ratings"].float())
            l2_penalty = trainable_l2_penalty(model)
            loss = (
                rating_loss
                + args.zeta_generation * generation_loss
                + args.gamma_category_contrastive * contrastive_loss
                + args.l2_eta * l2_penalty
            ) / args.gradient_accumulation_steps
        scaler.scale(loss).backward()
        should_update = step % args.gradient_accumulation_steps == 0 or step == len(loader)
        if should_update:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad(set_to_none=True)
            scheduler.step()
        total += float(loss.item() * args.gradient_accumulation_steps)
        total_gen += float(generation_loss.item())
        total_rating += float(rating_loss.item())
        total_contrastive += float(contrastive_loss.item())
        total_l2 += float(l2_penalty.item())
    denominator = max(1, len(loader))
    return {
        "loss": total / denominator,
        "generation_loss": total_gen / denominator,
        "rating_mse": total_rating / denominator,
        "category_contrastive_loss": total_contrastive / denominator,
        "l2_penalty": total_l2 / denominator,
    }


@torch.no_grad()
def evaluate_rating(model, loader, device) -> Dict[str, float]:
    model.eval()
    predictions, targets = [], []
    for batch in tqdm(loader, desc="Rating evaluation"):
        batch = move_batch(batch, device)
        _, _, _, prediction, _, _ = forward_batch(model, batch, with_language=False)
        prediction = prediction.clamp(1.0, 5.0)
        predictions.extend(prediction.detach().cpu().tolist())
        targets.extend(batch["ratings"].detach().cpu().tolist())
    errors = np.asarray(predictions, dtype=np.float64) - np.asarray(targets, dtype=np.float64)
    mse = float(np.mean(errors ** 2))
    return {"RMSE": math.sqrt(mse), "MAE": float(np.mean(np.abs(errors)))}


@torch.no_grad()
def evaluate_losses(
    model, loader, device, zeta_generation: float, gamma_category_contrastive: float, l2_eta: float
) -> Dict[str, float]:
    model.eval()
    generation_total, rating_total, contrastive_total = 0.0, 0.0, 0.0
    for batch in tqdm(loader, desc="Validation loss"):
        batch = move_batch(batch, device)
        language_output, _, _, rating_prediction, contrastive_loss, _ = forward_batch(
            model, batch, with_language=True
        )
        rating_prediction = rating_prediction.clamp(1.0, 5.0)
        generation_total += float(language_output.loss.item())
        rating_total += float(F.mse_loss(rating_prediction.float(), batch["ratings"].float()).item())
        contrastive_total += float(contrastive_loss.item())
    denominator = max(1, len(loader))
    generation_loss = generation_total / denominator
    rating_mse = rating_total / denominator
    contrastive_loss = contrastive_total / denominator
    l2_penalty = float(trainable_l2_penalty(model).item())
    return {
        "generation_loss": generation_loss,
        "rating_mse": rating_mse,
        "category_contrastive_loss": contrastive_loss,
        "l2_penalty": l2_penalty,
        "selection_loss": (
            rating_mse
            + zeta_generation * generation_loss
            + gamma_category_contrastive * contrastive_loss
            + l2_eta * l2_penalty
        ),
    }


def trainable_state_dict(model: MyModel) -> Dict[str, torch.Tensor]:
    trainable = {name for name, parameter in model.named_parameters() if parameter.requires_grad}
    return {
        name: value.detach().cpu()
        for name, value in model.state_dict().items()
        if name in trainable
    }


def make_loader(
    dataset,
    collator,
    batch_size: int,
    shuffle: bool,
    workers: int,
    category_aware: bool = False,
    samples_per_category: int = 2,
    seed: int = 42,
) -> DataLoader:
    kwargs = dict(
        dataset=dataset,
        num_workers=workers,
        pin_memory=torch.cuda.is_available(),
        collate_fn=collator,
        persistent_workers=workers > 0,
    )
    if shuffle and category_aware:
        kwargs["batch_sampler"] = CategoryAwareBatchSampler(
            dataset,
            batch_size=batch_size,
            samples_per_category=samples_per_category,
            seed=seed,
            drop_last=False,
        )
    else:
        kwargs["batch_size"] = batch_size
        kwargs["shuffle"] = shuffle
    if workers > 0:
        kwargs["prefetch_factor"] = 2
    return DataLoader(**kwargs)


def validate_split_integrity(
    train_frame: pd.DataFrame, valid_frame: pd.DataFrame, test_frame: pd.DataFrame
) -> Dict[str, float]:
    """Fail before training when a user-item target crosses split boundaries."""
    def keys(frame: pd.DataFrame) -> set[Tuple[str, str]]:
        return set(zip(frame["user_id"].astype(str), frame["item"].astype(str)))

    train_keys, valid_keys, test_keys = keys(train_frame), keys(valid_frame), keys(test_frame)
    overlap = (train_keys & valid_keys) | (train_keys & test_keys) | (valid_keys & test_keys)
    if overlap:
        raise RuntimeError(f"Split leakage: {len(overlap)} user-item pairs occur in multiple splits")
    train_users = set(train_frame["user_id"].astype(str))
    train_items = set(train_frame["item"].astype(str))
    return {
        "valid_user_history_coverage": float(valid_frame["user_id"].astype(str).isin(train_users).mean()),
        "test_user_history_coverage": float(test_frame["user_id"].astype(str).isin(train_users).mean()),
        "valid_item_train_coverage": float(valid_frame["item"].astype(str).isin(train_items).mean()),
        "test_item_train_coverage": float(test_frame["item"].astype(str).isin(train_items).mean()),
    }


def validate_image_attachment(
    frames: Dict[str, pd.DataFrame],
    require_images: bool,
    minimum_coverage: float,
) -> Dict[str, Dict[str, float]]:
    """Measure usable image coverage and optionally block a fake multimodal run.

    A non-empty JSON field is not sufficient: the referenced file must exist.
    This check runs before CLIP/OpenLLaMA are loaded, so an unfinished image
    download or missing JSONL write-back fails quickly without consuming GPU
    memory.
    """
    report: Dict[str, Dict[str, float]] = {}
    for split, frame in frames.items():
        paths = frame["image_path"].fillna("").astype(str)
        # Many interactions share an item, so stat each unique path once.
        existing_paths = {
            path for path in paths.unique().tolist() if path and os.path.isfile(path)
        }
        available = int(paths.isin(existing_paths).sum())
        total = int(len(frame))
        coverage = available / max(1, total)
        report[split] = {
            "rows": total,
            "rows_with_existing_image": available,
            "interaction_image_coverage": coverage,
        }
        if require_images and coverage < minimum_coverage:
            raise RuntimeError(
                f"{split} image coverage {coverage:.4%} is below the required "
                f"{minimum_coverage:.4%}. Finish download_amazon_images.py and "
                "finalize_amazon_images.py before starting multimodal training."
            )
    return report


def build_components(args: Namespace):
    seed_everything(args.seed)
    if not 0.0 <= args.min_image_coverage <= 1.0:
        raise ValueError("--min_image_coverage must be between 0 and 1")
    if args.early_stopping_patience < 0:
        raise ValueError("--early_stopping_patience must be non-negative")
    if args.early_stopping_min_delta < 0.0:
        raise ValueError("--early_stopping_min_delta must be non-negative")
    if args.max_target_len != 20 or args.max_new_tokens != 20:
        print(
            "WARNING: max_target_len/max_new_tokens are not both 20; "
            "this run is not CIER-length comparable."
        )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    os.makedirs(args.ckpt_dir, exist_ok=True)
    data_manager = DashDataManager(
        train_file=args.train_file,
        valid_file=args.valid_file,
        test_file=args.test_file,
        data_file=args.data_file,
        dataset_name=args.dataset_name,
        debug_max_samples=args.debug_max_samples,
    )
    train_frame, valid_frame, test_frame = data_manager.frames()
    integrity = validate_split_integrity(train_frame, valid_frame, test_frame)
    image_attachment = validate_image_attachment(
        {"train": train_frame, "valid": valid_frame, "test": test_frame},
        require_images=args.require_images,
        minimum_coverage=args.min_image_coverage,
    )
    global_mean = compute_global_rating_mean(train_frame)
    print(
        f"users={data_manager.num_users} items={data_manager.num_items} "
        f"categories={data_manager.num_categories} train={len(train_frame)} "
        f"valid={len(valid_frame)} test={len(test_frame)}"
    )
    print("split integrity:", json.dumps(integrity, indent=2))
    print("image attachment:", json.dumps(image_attachment, indent=2))

    clip_processor = CLIPProcessor.from_pretrained(args.clip_path, local_files_only=True)
    tokenizer, llm = init_llm(args, device)
    hidden_size = int(getattr(llm.config, "hidden_size", llm.get_input_embeddings().embedding_dim))
    model = MyModel(
        llm_hidden=hidden_size,
        feat_dim=args.feat_dim,
        num_categories=data_manager.num_categories,
        num_users=data_manager.num_users,
        num_items=data_manager.num_items,
        global_rating_mean=global_mean,
        clip_path=args.clip_path,
        prefix_len=args.prefix_len,
        freeze_clip=not args.train_clip,
        modality_layers=args.modality_layers,
        contrastive_temperature=args.contrastive_temperature,
        cache_clip_features=not args.no_clip_cache,
        no_cmfa=args.no_cmfa,
        no_cmpm=args.no_cmpm,
        no_cidm=args.no_cidm,
    ).to(device)
    model.model = llm.to(device)
    model.tokenizer = tokenizer

    collator = MyCollater(
        clip_processor,
        tokenizer,
        max_history_items=args.max_history_items,
        max_prompt_len=args.max_prompt_len,
        max_target_len=args.max_target_len,
        include_user_history=True,
        include_user_identifier=True,
        prompt_history_topk=args.prompt_history_topk,
        prompt_with_example=not args.no_prompt_example,
    )
    dataset_kwargs = dict(
        data_manager=data_manager,
        global_mean=global_mean,
        max_history_items=args.max_history_items,
        profile_topk=args.profile_topk,
        recent_items=args.recent_items,
    )
    train_dataset = MyDataset(train_frame, history_dataframe=train_frame, leave_one_out_history=True, **dataset_kwargs)
    valid_dataset = MyDataset(valid_frame, history_dataframe=train_frame, **dataset_kwargs)
    # Formal protocol: validation and test prompts can see training records
    # only.  Validation reviews must never become test-user evidence.
    test_dataset = MyDataset(test_frame, history_dataframe=train_frame, **dataset_kwargs)
    train_loader = make_loader(
        train_dataset,
        collator,
        args.batch_size,
        True,
        args.num_workers,
        category_aware=args.category_aware_sampling,
        samples_per_category=args.samples_per_category,
        seed=args.seed,
    )
    valid_loader = make_loader(valid_dataset, collator, args.batch_size, False, args.num_workers)
    test_loader = make_loader(test_dataset, collator, args.batch_size, False, args.num_workers)
    print(
        "training sampler:",
        "category-aware" if args.category_aware_sampling else "random",
        f"batch_size={args.batch_size}",
        f"samples_per_category={args.samples_per_category}",
    )

    optimizer = build_optimizer(model, args)
    updates_per_epoch = math.ceil(len(train_loader) / args.gradient_accumulation_steps)
    total_updates = max(1, updates_per_epoch * args.epochs)
    warmup = min(args.warmup_steps, max(0, int(total_updates * args.warmup_ratio)))
    scheduler = get_linear_schedule_with_warmup(optimizer, warmup, total_updates)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")

    mappings = {
        "user2id": data_manager.user2id,
        "item2id": data_manager.item2id,
        "category2id": data_manager.category2id,
        "global_rating_mean": global_mean,
        "history_policy": "training split only; timestamp strictly earlier than target",
        "target_policy": f"first {args.max_target_len} tokenizer BPE tokens",
        "split_integrity": integrity,
        "image_attachment": image_attachment,
    }
    with open(os.path.join(args.ckpt_dir, "training_mappings.json"), "w", encoding="utf-8") as handle:
        json.dump(mappings, handle, ensure_ascii=False, indent=2)
    with open(os.path.join(args.ckpt_dir, "experiment_config.json"), "w", encoding="utf-8") as handle:
        json.dump(
            {
                "arguments": vars(args),
                "protocol": {
                    "history": "training split only and timestamp < target timestamp",
                    "target": "template[2] when present, else explanation_text; tokenizer-BPE truncated",
                    "feature": "template[0] when present, else review_features",
                    "rouge": "ROUGE-1/2 recall and ROUGE-L F1",
                },
                "split_integrity": integrity,
                "image_attachment": image_attachment,
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )
    return model, train_loader, valid_loader, test_loader, test_dataset, collator, optimizer, scheduler, scaler, device


def run_training(args: Namespace) -> None:
    components = build_components(args)
    model, train_loader, valid_loader, test_loader, test_dataset, collator, optimizer, scheduler, scaler, device = components
    if args.resume_trainable:
        resumed = torch.load(args.resume_trainable, map_location=device)
        model.load_state_dict(resumed.get("model", resumed), strict=False)
        print(f"loaded trainable checkpoint: {args.resume_trainable}")
    if args.eval_only:
        if not args.resume_trainable:
            raise ValueError("--eval_only requires --resume_trainable")
        evaluation_loader = valid_loader if args.eval_split == "valid" else test_loader
        if args.max_generation_samples and args.max_generation_samples > 0:
            count = min(args.max_generation_samples, len(evaluation_loader.dataset))
            evaluation_loader = make_loader(
                Subset(evaluation_loader.dataset, range(count)),
                collator,
                args.batch_size,
                False,
                args.num_workers,
            )
        model.model.config.use_cache = True
        print(
            f"{args.eval_split} rating:",
            json.dumps(evaluate_rating(model, evaluation_loader, device), indent=2),
        )
        metrics = generate_and_eval(
            model,
            evaluation_loader,
            device,
            args,
            save_path=os.path.join(
                args.ckpt_dir,
                f"generation_{args.eval_split}_{args.decoding_strategy}_results.jsonl",
            ),
        )
        print(f"{args.eval_split} generation:", json.dumps(metrics, indent=2, sort_keys=True))
        return
    best_selection_loss = float("inf")
    best_epoch = 0
    epochs_without_improvement = 0
    best_path = os.path.join(args.ckpt_dir, "best_trainable.pt")
    training_history = []

    for epoch in range(1, args.epochs + 1):
        print(f"\n===== Epoch {epoch}/{args.epochs} =====")
        train_metrics = train_one_epoch(model, train_loader, optimizer, scheduler, scaler, device, args)
        validation_metrics = evaluate_losses(
            model, valid_loader, device, args.zeta_generation, args.gamma_category_contrastive, args.l2_eta
        )
        print("train:", json.dumps(train_metrics, indent=2))
        print("validation:", json.dumps(validation_metrics, indent=2))

        current_selection_loss = float(validation_metrics["selection_loss"])
        if not math.isfinite(current_selection_loss):
            raise RuntimeError(
                f"Non-finite validation selection_loss at epoch {epoch}: "
                f"{current_selection_loss}"
            )

        improved = current_selection_loss < (
            best_selection_loss - args.early_stopping_min_delta
        )
        training_history.append(
            {
                "epoch": epoch,
                "train": train_metrics,
                "validation": validation_metrics,
                "improved": improved,
            }
        )
        with open(
            os.path.join(args.ckpt_dir, "training_history.json"),
            "w",
            encoding="utf-8",
        ) as handle:
            json.dump(training_history, handle, ensure_ascii=False, indent=2)

        if improved:
            best_selection_loss = current_selection_loss
            best_epoch = epoch
            epochs_without_improvement = 0
            torch.save(
                {
                    "model": trainable_state_dict(model),
                    "epoch": epoch,
                    "validation": validation_metrics,
                    "early_stopping": {
                        "monitor": "selection_loss",
                        "mode": "min",
                        "patience": args.early_stopping_patience,
                        "min_delta": args.early_stopping_min_delta,
                    },
                },
                best_path,
            )
            print(
                f"validation selection_loss improved to "
                f"{best_selection_loss:.6f}; saved {best_path}"
            )
        else:
            epochs_without_improvement += 1
            if args.early_stopping_patience > 0:
                print(
                    "validation selection_loss did not improve by at least "
                    f"{args.early_stopping_min_delta:g}; "
                    f"early-stopping counter "
                    f"{epochs_without_improvement}/{args.early_stopping_patience}"
                )
                if epochs_without_improvement >= args.early_stopping_patience:
                    print(
                        f"early stopping triggered at epoch {epoch}; "
                        f"best epoch was {best_epoch} with selection_loss="
                        f"{best_selection_loss:.6f}"
                    )
                    break
            else:
                print("early stopping is disabled; continuing training")

    if not os.path.isfile(best_path):
        raise RuntimeError("Training finished without creating best_trainable.pt")
    checkpoint = torch.load(best_path, map_location=device)
    model.load_state_dict(checkpoint["model"], strict=False)
    print(
        f"loaded best checkpoint from epoch {checkpoint['epoch']} "
        f"with validation selection_loss="
        f"{checkpoint['validation']['selection_loss']:.6f}"
    )
    if args.validation_only:
        print("validation_only=true: best checkpoint selected without test evaluation")
        return
    print("test rating:", json.dumps(evaluate_rating(model, test_loader, device), indent=2))
    generation_loader = test_loader
    if args.max_generation_samples and args.max_generation_samples > 0:
        count = min(args.max_generation_samples, len(test_dataset))
        generation_loader = make_loader(
            Subset(test_dataset, range(count)), collator, args.batch_size, False, args.num_workers
        )
    model.model.config.use_cache = True
    generation_metrics = generate_and_eval(
        model,
        generation_loader,
        device,
        args,
        save_path=os.path.join(args.ckpt_dir, "generation_results.jsonl"),
    )
    print("test generation:", json.dumps(generation_metrics, indent=2, sort_keys=True))


def build_parser() -> ArgumentParser:
    parser = ArgumentParser()
    parser.add_argument("--train_file", type=str, default=None)
    parser.add_argument("--valid_file", type=str, default=None)
    parser.add_argument("--test_file", type=str, default=None)
    parser.add_argument("--data_file", type=str, default=None, help="Legacy single cleaned file; fixed splits are recommended")
    parser.add_argument("--dataset_name", type=str, default="amazon")
    parser.add_argument("--clip_path", type=str, required=True)
    parser.add_argument("--model_name", type=str, required=True)
    parser.add_argument("--ckpt_dir", type=str, default="./checkpoints/amazon_mt")
    parser.add_argument("--epochs", type=int, default=5, help="Maximum number of training epochs")
    parser.add_argument(
        "--early_stopping_patience",
        type=int,
        default=3,
        help=(
            "Stop after this many consecutive epochs without sufficient decrease "
            "in validation selection_loss; set to 0 to disable"
        ),
    )
    parser.add_argument(
        "--early_stopping_min_delta",
        type=float,
        default=0.0,
        help="Minimum validation selection_loss decrease counted as an improvement",
    )
    parser.add_argument("--batch_size", type=int, default=2)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=4)
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--require_images",
        action="store_true",
        help="Fail before model loading unless every split meets --min_image_coverage",
    )
    parser.add_argument(
        "--min_image_coverage",
        type=float,
        default=0.000001,
        help="Minimum existing-image interaction coverage per split when --require_images is set",
    )
    parser.add_argument(
        "--category_aware_sampling",
        action="store_true",
        default=True,
        help="Construct same-category positive pairs for the category contrastive loss (default: enabled)",
    )
    parser.add_argument(
        "--no_category_aware_sampling",
        dest="category_aware_sampling",
        action="store_false",
        help="Ablation/debug only: restore ordinary random mini-batches",
    )
    parser.add_argument(
        "--samples_per_category",
        type=int,
        default=2,
        help="Number of same-category target interactions per sampling unit",
    )
    parser.add_argument("--debug_max_samples", type=int, default=None)
    parser.add_argument("--max_generation_samples", type=int, default=None)
    parser.add_argument("--max_new_tokens", type=int, default=20)
    parser.add_argument("--min_new_tokens", type=int, default=6)
    parser.add_argument(
        "--decoding_strategy",
        choices=("greedy", "beam", "sample", "diverse_beam", "contrastive"),
        default="beam",
    )
    parser.add_argument("--num_beams", type=int, default=4)
    parser.add_argument("--temperature", type=float, default=0.1)
    parser.add_argument("--top_p", type=float, default=0.9)
    parser.add_argument("--top_k", type=int, default=50)
    parser.add_argument("--penalty_alpha", type=float, default=0.6)
    parser.add_argument("--contrastive_top_k", type=int, default=4)
    parser.add_argument("--length_penalty", type=float, default=1.0)
    parser.add_argument("--repetition_penalty", type=float, default=1.05)
    parser.add_argument("--no_repeat_ngram_size", type=int, default=3)
    parser.add_argument("--resume_trainable", type=str, default=None)
    parser.add_argument("--eval_only", action="store_true")
    parser.add_argument("--eval_split", choices=("valid", "test"), default="valid")
    parser.add_argument(
        "--eval_protocol",
        choices=("cier", "extended"),
        default="cier",
        help="CIER uses its public unsmoothed BLEU and test-feature metric definitions",
    )
    parser.add_argument("--zeta_generation", type=float, default=1.0)
    parser.add_argument("--gamma_category_contrastive", type=float, default=0.1)
    parser.add_argument("--l2_eta", type=float, default=1e-3)
    parser.add_argument("--contrastive_temperature", type=float, default=0.07)
    parser.add_argument("--lora_lr", type=float, default=1e-4)
    parser.add_argument("--prefix_lr", type=float, default=1e-3)
    parser.add_argument("--rating_lr", type=float, default=1e-3)
    parser.add_argument("--warmup_steps", type=int, default=100)
    parser.add_argument("--warmup_ratio", type=float, default=0.05)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--lora_r", type=int, default=8)
    parser.add_argument("--lora_alpha", type=int, default=32)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument("--feat_dim", type=int, default=512)
    parser.add_argument("--prefix_len", type=int, default=16)
    parser.add_argument("--max_prompt_len", type=int, default=160)
    parser.add_argument("--max_target_len", type=int, default=20)
    parser.add_argument("--max_history_items", type=int, default=20)
    parser.add_argument("--profile_topk", type=int, default=3)
    parser.add_argument("--prompt_history_topk", type=int, default=3)
    parser.add_argument("--recent_items", type=int, default=0)
    parser.add_argument("--modality_layers", type=int, default=2)
    parser.add_argument("--train_clip", action="store_true")
    parser.add_argument("--no_clip_cache", action="store_true", help="Disable frozen CLIP token cache")
    parser.add_argument("--validation_only", action="store_true", help="Select checkpoint but never evaluate test")
    parser.add_argument("--no_cmfa", action="store_true", help="Paper ablation: replace category-guided alignment with linear pooling")
    parser.add_argument("--no_cmpm", action="store_true", help="Paper ablation: average available user modalities")
    parser.add_argument("--no_cidm", action="store_true", help="Paper ablation: use category-independent temporal decay")
    parser.add_argument("--no_prompt_example", action="store_true", help="Remove the fixed demonstration from the structured prompt")
    return parser


if __name__ == "__main__":
    run_training(build_parser().parse_args())
